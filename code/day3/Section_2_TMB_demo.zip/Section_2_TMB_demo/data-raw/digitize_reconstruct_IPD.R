#* Title: digitize_reconstruct_IPD  
#* 
#* Code function:
#*    This script digitizes, and reconstructs the Individual Patient Data (IPD)
#*    from published survival curves
#* 
#* - David U. Garibay-Treviño and Alexandra Moskalewicz on behalf of the DARTH work group

# 01 Initial Setup --------------------------------------------------------

## 01.01 Clean environment ------------------------------------------------

rm(list = ls())
gc()

## 01.02 Load libraries ----------------------------------------------------

# Install packages from CRAN (if required) and load packages
if (!require('pacman')) install.packages('pacman'); library(pacman)
p_load("tidyverse", "survival", "SurvdigitizeR", "IPDfromKM")

#devtools::install_github("Pechli-Lab/SurvdigitizeR") #unhide if installing SurvdigitizeR package for the first time

## 01.03 Load functions ----------------------------------------------------

#No functions are required in this file

## 01.04 Specifications ----------------------------------------------------

#* Possible interventions:
#* 1. "TMB_more"
#* 2. "TMB_less"

# Keep only the columns related to time and survival probabilities for the 
# intervention group of interest
intervention <- "TMB_less"

# 02 Digitize published survival curves -------------------------------------

## 02.01 Apply SurvdigitizeR to OS and PFS curves ----------------------------------------------

# Specify image paths and intervention

OS_img_path   <- paste0("Section_2_TMB_demo/figs/TMB_OS_clean.png")
PFS_img_path  <- paste0("Section_2_TMB_demo/figs/TMB_PFS_clean.png")

# Digitize the plotted OS KM curve
os_curve_dig <- SurvdigitizeR::survival_digitize(
  img_path        = OS_img_path,
  num_curves      = 2,
  x_start         = 0,
  x_end           = 18,
  x_increment     = 3,
  y_start         = 0,
  y_end           = 1,
  y_increment     = 0.25,
  censoring       = T,
  y_text_vertical = T,
  line_censoring  = F)

#Visualize digitized OS
ggplot(data = os_curve_dig, 
       mapping = aes(x     = time, 
                     y     = St, 
                     color = factor(curve), 
                     group = curve)) +
  geom_step() +
  theme_bw() +
  scale_x_continuous(breaks = seq(0, 18, 3)) +
  ylim(0,1) +
  labs(color = "Curves", 
       x     = "Time", 
       y     = "OS Survival Probability")


# Digitize the plotted PFS KM curve
pfs_curve_dig <- SurvdigitizeR::survival_digitize(
  img_path = PFS_img_path,
  num_curves      = 2,
  x_start         = 0,
  x_end           = 18,
  x_increment     = 3,
  y_start         = 0,
  y_end           = 1,
  y_increment     = 0.25,
  censoring       = F,
  y_text_vertical = T,
  line_censoring  = F)

#Visualize digitized PFS
ggplot(pfs_curve_dig, aes(x    = time, 
                          y    = St, 
                          color = factor(curve), 
                          group = curve)) +
  geom_step() +
  theme_bw() +
  scale_x_continuous(breaks = seq(0, 18, 3)) +
  ylim(0,1) +
  labs(color = "Curves", 
       x     = "Time", 
       y     = "PFS Survival Probability")


## 02.02 Save digitized KM curves ------------------------------------------

# Keep only the columns related to time and survival probabilities
if (intervention  == "TMB_less") {
  # OS
  os_curve_dig <- os_curve_dig %>% 
    filter(curve == 1) %>%
    select(time, St)
  # PFS
  pfs_curve_dig <- pfs_curve_dig %>% 
    filter(curve == 1) %>%
    select(time, St)
}
if (intervention  == "TMB_more") {
  # OS
  os_curve_dig <- os_curve_dig %>% 
    filter(curve == 2) %>%
    select(time, St)
  # PFS
  pfs_curve_dig <- pfs_curve_dig %>% 
    filter(curve == 2) %>%
    select(time, St)
}

# Save digitized data coming from plots of the digitized KM curves
write.csv(os_curve_dig,  file = paste0("Section_2_TMB_demo/data-raw/", intervention, "/OS_digitized.csv"),  row.names = FALSE)
write.csv(pfs_curve_dig, file = paste0("Section_2_TMB_demo/data-raw/", intervention, "/PFS_digitized.csv"), row.names = FALSE)

# 03 Reconstruct IPD -------------------------------------

## 03.01 Specify at-risk information -----------------------------------------

#* Notes:
#* at-risk information is not mandatory to run generate_IPDfromKM()
#* however, it is recommended if this information is available in a trial publication or elsewhere
  
if (intervention  == "TMB_less") {
  
  # Number of people at risk in the OS arm
  OS_nrisk <- c(1460, 1071, 820, 670, 543, 433, 340)
  OS_trisk <- seq(0, 18, by = 3)
  
  # Number of people at risk in the PFS arm
  PFS_nrisk <- c(1460, 718, 428, 292, 218, 165, 121)
  PFS_trisk <- seq(0, 18, by = 3)
  
}

if (intervention  == "TMB_more") {
  
  # Number of people at risk in the OS arm
  OS_nrisk <- c(234, 187, 162, 146, 132, 111, 89)
  OS_trisk <- seq(0, 18, by = 3)
  
  # Number of people at risk in the PFS arm
  PFS_nrisk <- c(234, 134, 116, 94, 70, 54, 42)
  PFS_trisk <- seq(0, 18, by = 3)
  
}


## 03.02 Reconstruct IPD from digitized KM curves --------------------------

#OS
preprocess_OS <- IPDfromKM::preprocess(dat = os_curve_dig, 
                                         trisk = OS_trisk, 
                                         nrisk = OS_nrisk, 
                                         maxy  = 1)
  
est_OS <- IPDfromKM::getIPD(prep  = preprocess_OS,
                            tot.events = NULL)
  
#PFS
preprocess_PFS <- IPDfromKM::preprocess(dat = pfs_curve_dig, 
                                          trisk = PFS_trisk, 
                                          nrisk = PFS_nrisk, 
                                          maxy  = 1)
  
est_PFS <- IPDfromKM::getIPD(prep  = preprocess_PFS,
                             tot.events = NULL)

  
#* Join IPD from both OS/PFS into one data frame
df_IPD_all <- dplyr::bind_rows(OS  = est_OS$IPD, 
                               PFS = est_PFS$IPD, 
                               .id = "type")
  
write.csv(x = df_IPD_all,
          file = paste0("Section_2_TMB_demo/data-raw/", intervention, "/IPD_reconstructed.csv"),
          row.names = FALSE)

