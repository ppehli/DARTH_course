# 00 Digitization function ------------------------------------------------

# Generates IPD data using the IPDfromKM function
generate_IPDfromKM <- function(path, 
                               tot.e = NULL, 
                               nrisk,
                               trisk,
                               maxy){
  
  # Arguments:
  # path: the file path to .csv with times, overall survival probabilities
  # tot.e: the total events that occurred
  # nrisk: the no. of patients at risk at given times points
  # trisk: the time intervals at which the nrisk are given
  
  # Returns:
  # IPDfromKM object
  
  #Read in data
  KM   <- read.csv(path)
  
  
  #Preprocess coordinates
  #Intervention group
  preprocess_KM <- IPDfromKM::preprocess(dat   = KM, 
                                         trisk = trisk, 
                                         nrisk = nrisk, 
                                         maxy  = maxy)
  
  #Get IPDs and plot them
  #Overall survival, intervention
  est_surv          <- IPDfromKM::getIPD(prep       = preprocess_KM, 
                                         tot.events = tot.e)
  
  list <- list(IPD = est_surv$IPD,
               unit = est_surv)
  return(list)
  
}

# 01 Model input functions ------------------------------------------------

#' Load all parameters
#'
#' \code{load_params_all} loads all parameters for the decision model from multiple sources and creates a list.
#'
#' @param l_params_init Initial set of parameters which can be loaded using `load_params_init()` (default)#'
#' @return A list of all parameters used for the decision model.
#' @export
load_params_all <- function(v_time             = NULL,
                            model_cycle_length = NULL,
                            v_target_time      = NULL,
                            intervention       = NULL,
                            dt_base            = NULL,
                            dist_PF_P          = c("exp", "weibull","weibullPH", "gompertz", "gamma", "lnorm", "llogis"),
                            dist_PF_D          = c("exp", "weibull","weibullPH", "gompertz", "gamma", "lnorm", "llogis"),
                            dist_P_D           = c("exp", "weibull","weibullPH", "gompertz", "gamma", "lnorm", "llogis"),
                            param_1_PF_P       = NULL,
                            param_2_PF_P       = NULL,
                            param_3_PF_P       = NULL,
                            param_1_PF_D       = NULL,
                            param_2_PF_D       = NULL,
                            param_3_PF_D       = NULL,
                            param_1_P_D        = NULL,
                            param_2_P_D        = NULL,
                            param_3_P_D        = NULL){
  
  #* *Error checking*
  # Check if the selected distribution is in the available set
  dist_PF_P <- match.arg(dist_PF_P)
  dist_PF_D <- match.arg(dist_PF_D)
  dist_P_D  <- match.arg(dist_P_D)
  
  # Check that key arguments are provided
  stopifnot(
    "Please provide a numeric vector for `v_time`"        = !is.null(v_time),
    "Please provide a numeric vector for `v_time`"        = is.numeric(v_time),
    "Please provide a numeric vector for `v_target_time`" = !is.null(v_target_time),
    "Please provide a numeric vector for `v_target_time`" = is.numeric(v_target_time),
    "Please provide values greater than or equal to 0 in `v_time`" = all(v_time >= 0)
  )
  
  # Filter dt_base to match v_target_time
  dt_base <- dt_base[time %in% v_target_time]
  
  #* *Import calibration targets*
  
  # Obtain vector of targets
  ## for Overall survival (OS)
  v_targets_OS  <- dt_base[time %in% v_target_time & type == "OS"]$survival
  ## for Progression-free survival (PFS)
  v_targets_PFS <- dt_base[time %in% v_target_time & type == "PFS"]$survival
  
  ## Obtain vector of standard error of targets
  ## for Overall survival (OS)
  v_targets_se_OS  <- dt_base[time %in% v_target_time & type == "OS"]$se
  ## for Progression-free survival (PFS)
  v_targets_se_PFS <- dt_base[time %in% v_target_time & type == "PFS"]$se
  
  # Assign names to values on vectors
  names(v_targets_OS)    <- names(v_targets_PFS)    <- v_target_time
  names(v_targets_se_OS) <- names(v_targets_se_PFS) <- v_target_time
  
  #* *General setup*
  
  # Number of cycles
  n_cycles <- length(v_time)
  
  # Define vector with the health states of the model
  v_names_states <- c("PF", "P", "D")
  
  # number of health states
  n_states <- length(v_names_states)
  
  #* Create data.table with the distribution of each transition and the 
  #* the names of the parameters of every transition
  dt_bounds <- gen_bounds_2(dist_PF_P = dist_PF_P,
                            dist_PF_D = dist_PF_D,
                            dist_P_D  = dist_P_D)
  
  
  # Create list with additional parameters
  l_params_all <- list(
    intervention       = intervention,
    dt_base            = dt_base,
    v_names_states     = v_names_states,
    n_states           = n_states,
    n_cycles           = n_cycles,
    v_time             = v_time,
    model_cycle_length = model_cycle_length,
    v_target_time      = v_target_time,
    dist_PF_D          = dist_PF_D,
    dist_P_D           = dist_P_D,
    dist_PF_P          = dist_PF_P,
    dt_bounds          = dt_bounds,
    param_1_PF_P       = param_1_PF_P,
    param_2_PF_P       = param_2_PF_P,
    param_3_PF_P       = param_3_PF_P,
    param_1_P_D        = param_1_P_D,
    param_2_P_D        = param_2_P_D,
    param_3_P_D        = param_3_P_D,
    param_1_PF_D       = param_1_PF_D,
    param_2_PF_D       = param_2_PF_D,
    param_3_PF_D       = param_3_PF_D,
    v_targets_OS       = v_targets_OS,
    v_targets_PFS      = v_targets_PFS,
    v_targets_se_OS    = v_targets_se_OS,
    v_targets_se_PFS   = v_targets_se_PFS)
  
  # Export l_params_all
  return(l_params_all)
  
  
  #* Include initial set of parameters to `l_params_all`
  l_params_all <- modifyList(x = l_params_init, val = l_params_all) 
  
  return(l_params_all)
}


#' Update parameters
#' 
#' \code{update_param_list} updates the list of all parameters with new values 
#' for specific parameters.
#'
#' @param l_params_all List with all parameters of decision model.
#' @param params_updated Named list or vector with parameters for which values need to be updated
#'
#' @return A list with updated parameters
#' @export
update_param_list <- function(l_params_all, params_updated){
  
  if (typeof(params_updated) != "list") {
    # Converts named vector to a list
    params_updated <- split(unname(params_updated), names(params_updated)) 
  }
  
  # Update the list values
  l_params_all <- modifyList(l_params_all, params_updated) 
  
  return(l_params_all)
}


# 02 Model functions ------------------------------------------------------

#' General multi-state model
#' 
#' \code{threestate_model} is the main way to implement the multi-state model. 
#'
#' @param l_params_all List with all parameters of multi-state model
#' @param model_type Currently only markov (`markov`) models are being supported.
#'
#' @return
#' A list:
#' \itemize{\item \code{a_P}: Transition probability array.
#'          \item \code{m_M}: Cohort trace matrix.
#'          \item \code{a_A}: Dynamic transition array (only for `cohort`),
#'          \item \code{m_M_ind}: Matrix showing the individuals' states across cycles (only for `microsim`),
#'          \item \code{v_os}: Vector with the overall survival proportion of the cohort across cycles.
#'          \item \code{le_cycle}: Life expectancy of the cohort, in cycles.
#'          \item \code{le_years}: Life expectancy of the cohort, in years.
#'          }
#' @export
threestate_model <- function(l_params_all, 
                             model_type = "markov") {
  
  
  # Error checking --------------------------------------------------------- -
  #* Check if selected `model_type` is in the available options set 
  model_type <- match.arg(model_type)
  
  # Execute model type based on selection ---------------------------------- -
  switch(model_type,
         
         # Execute markov cohort state transition model with tunnels     
         markov = threestate_model_markov(l_params_all = l_params_all)
  )
}


#' Multi-state model for a markov cohort state transition model
#' 
#' \code{threestate_model_markov} implements the three state model using a markov model with tunnels.
#'
#' @param l_params_all List with all parameters of three state model
#'
#' @return
#' A list with two elements:
#' \itemize{\item \code{m_M}: Cohort trace matrix,
#'          \item \code{df_calib}: Data frame with health outcomes (OS and PFS)
#'          }
#' @export
threestate_model_markov <- function(l_params_all) {
  
  
  # with(data = l_params_all, expr = {
  x <- l_params_all
  
  # # Comment for debugging only
  # list2env(x = l_params_all, envir = globalenv())
  
  
  #* *Retrieve parameters* 
  
  n_cycles <- length(x$v_time) - 1
  
  # Add cycle names
  v_names_cycles  <- paste("cycle", x$v_time)
  
  #* *Tunnels*
  
  ## Define tunnel size equal to the number of cycles
  n_tunnel_size <- n_cycles
  
  # # Progression health state
  v_prog_tunnel <- paste0("Progressed_", 1:n_cycles)
  # Progression health state
  # v_prog_tunnel <-  1:n_cycles
  
  # Define names of possible health states in the model
  v_names_states_tunnels  <- c("Progression-free", v_prog_tunnel, "Death")
  
  # Number of possible health states in model
  n_states_tunnels <- length(v_names_states_tunnels)
  
  # Define transition rates
  
  ## from Progression-free (PF) to Progression (P)
  v_r_PF_P <- create_transition_rate(distribution = x$dist_PF_P,
                                     v_time       = x$v_time,
                                     param_1      = x$param_1_PF_P,
                                     param_2      = x$param_2_PF_P,
                                     param_3      = x$param_3_PF_P)
  ## from Progression-free (PF) to Death (D)
  v_r_PF_D <- create_transition_rate(distribution = x$dist_PF_D,
                                     v_time       = x$v_time,
                                     param_1      = x$param_1_PF_D,
                                     param_2      = x$param_2_PF_D,
                                     param_3      = x$param_3_PF_D)
  ## from Progression (P) to Death (D)
  v_r_P_D <- create_transition_rate(distribution = x$dist_P_D,
                                    v_time       = x$v_time,
                                    param_1      = x$param_1_P_D,
                                    param_2      = x$param_2_P_D,
                                    param_3      = x$param_3_P_D)
  
  #* Convert rates into probabilities
  v_p_PF_D <- 1 - exp(-v_r_PF_D) 
  v_p_P_D  <- 1 - exp(-v_r_P_D) 
  v_p_PF_P <- 1 - exp(-v_r_PF_P)
  
  # Initialize cohort traces with tunnels
  ## Initialize cohort trace for state-residence dependent cohort State
  ## Transition Matrix
  m_M_tunnels <- matrix(data     = 0,
                        nrow     = (n_cycles + 1),
                        ncol     = n_states_tunnels,
                        dimnames = list(0:n_cycles, v_names_states_tunnels))
  #* Store the initial state vector in the first row of the cohort trace
  #* *Everyone starts in the Progression-free health state*
  m_M_tunnels[1, ] <- c(1, rep(0, n_tunnel_size), 0)
  
  ##Create transition probability arrays
  
  # Create transition probability arrays for strategy SoC
  # * - Initialize 3-dimensional array containing transition probabilities
  # * - All transitions to a non-death state are assumed to be conditional on
  # *   survival
  # a_P_tunnels <- array(
  #   data     = 0,
  #   dim      = c(n_states_tunnels,
  #                n_states_tunnels,
  #                n_cycles),
  #   dimnames = list(v_names_states_tunnels,
  #                   v_names_states_tunnels,
  #                   v_names_cycles[-length(v_names_cycles)]))
  # 
  # # Fill in array
  # ## from Progression-Free (PF)
  # a_P_tunnels["Progression-free", "Progression-free", ] <- (1 - v_p_PF_D)*(1 - v_p_PF_P)
  # a_P_tunnels["Progression-free", "Progressed_1", ]     <- (1 - v_p_PF_D)*     v_p_PF_P
  # a_P_tunnels["Progression-free", "Death", ]            <-      v_p_PF_D
  # 
  # ## from Progressed (P)
  # for(i in 1:(n_tunnel_size - 1)){
  #   # i <- 1
  #   a_P_tunnels[v_prog_tunnel[i], v_prog_tunnel[i + 1], ] <- 1 - v_p_P_D[i]
  #   a_P_tunnels[v_prog_tunnel[i], "Death", ]              <-     v_p_P_D[i]
  # }
  # 
  # a_P_tunnels[v_prog_tunnel[n_tunnel_size], v_prog_tunnel[n_tunnel_size], ] <- 1 - v_p_P_D[n_tunnel_size]
  # a_P_tunnels[v_prog_tunnel[n_tunnel_size], "Death", ]                      <-     v_p_P_D[n_tunnel_size]
  # 
  # # from Dead (D)
  # a_P_tunnels["Death", "Death", ] <- 1
  # 
  # a_P_tunnels <- matrix(
  #   data     = 0,
  #   nrow     = n_states_tunnels,
  #   ncol     = n_states_tunnels,
  #   dimnames = list(v_names_states_tunnels,
  #                   v_names_states_tunnels)
  # )
  # 
  # # Fill in array
  # ## from Progression-Free (PF)
  # a_P_tunnels["Progression-free", "Progression-free"] <- (1 - v_p_PF_D[1])*(1 - v_p_PF_P[1])
  # a_P_tunnels["Progression-free", "Progressed_1"]     <- (1 - v_p_PF_D[1])*     v_p_PF_P[1]
  # a_P_tunnels["Progression-free", "Death"]            <-      v_p_PF_D[1]
  # 
  # ## from Progressed (P)
  # for(i in 1:(n_tunnel_size - 1)){
  #   # i <- 1
  #   a_P_tunnels[v_prog_tunnel[i], v_prog_tunnel[i + 1]] <- 1 - v_p_P_D[1]
  #   a_P_tunnels[v_prog_tunnel[i], "Death"]              <-     v_p_P_D[1]
  # }
  # 
  # a_P_tunnels[v_prog_tunnel[n_tunnel_size], v_prog_tunnel[n_tunnel_size]] <- 1 - v_p_P_D[n_tunnel_size]
  # a_P_tunnels[v_prog_tunnel[n_tunnel_size], "Death"]                      <-     v_p_P_D[n_tunnel_size]
  # # browser()
  # # from Dead (D)
  # a_P_tunnels["Death", "Death"] <- 1
  # 
  # # # Check that all rows sum to 1
  # # darthtools::check_sum_of_transition_array(a_P      = a_P_tunnels,
  # #     n_states = n_states_tunnels,
  # #     n_cycles = n_cycles,
  # #     verbose  = F)
  # 
  # # Iterative solution of state-residence dependent cSTM
  # for (t in 1:n_cycles){
  #   ## Fill in cohort trace - for SoC
  #   # P_t <- a_P_tunnels
  #   m_M_tunnels [t + 1, ] <- m_M_tunnels [t, ] %*% a_P_tunnels
  # }
  # 
  # 
  # ## -----------------------------
  # ## Transition probability LIST
  # ## -----------------------------
  # 
  # a_P_tunnels <- vector("list", n_cycles)
  
  for (t in 1:n_cycles) {
    # t <- 1
    
    P_t <- matrix(
      0,
      nrow = n_states_tunnels,
      ncol = n_states_tunnels,
      dimnames = list(v_names_states_tunnels,
                      v_names_states_tunnels)
    )
    #
    #   # =====================================================
    #   # Progression-free transitions
    #   # =====================================================
    #
    #   P_t["Progression-free", "Progression-free"] <- (1 - v_p_PF_D[t]) * (1 - v_p_PF_P[t])
    #
    #   P_t["Progression-free", "Progressed_1"] <- (1 - v_p_PF_D[t]) * v_p_PF_P[t]
    #
    #   P_t["Progression-free", "Death"] <- v_p_PF_D[t]
    #
    #   # =====================================================
    #   # Progressed tunnel transitions
    #   # =====================================================
    #
    #   for (i in 1:n_tunnel_size) {
    #
    #     state <- v_prog_tunnel[i]
    #     p_death <- v_p_P_D[i]
    #
    #     if (i < n_tunnel_size) {
    #
    #       P_t[state, v_prog_tunnel[i + 1]] <- 1 - p_death
    #
    #     } else {
    #
    #       P_t[state, state] <- 1 - p_death
    #     }
    #
    #       P_t[state, "Death"] <- p_death
    #   }
    #  # set P_t to a matrix of zero
    #   m_M_tunnels[t + 1, ] <- m_M_tunnels[t, ] %*% P_t
    #   rm(P_t)
    # }
    
    # =====================================================
    # Progression-free transitions
    # =====================================================
    
    # PF to PF
    P_t[1, 1] <- (1 - v_p_PF_D[t]) * (1 - v_p_PF_P[t])
    # PF to Progressed_1
    P_t[1, 2] <- (1 - v_p_PF_D[t]) * v_p_PF_P[t]
    # PF to D
    P_t[1, ncol(P_t)] <- v_p_PF_D[t]
    
    # =====================================================
    # Progressed tunnel transitions
    # =====================================================
    
    for (i in 1:(n_tunnel_size - 1)) {
      
      p_death <- v_p_P_D[i]
      
      P_t[i+1, i+2] <- 1 - p_death
      
      P_t[i+1, ncol(P_t)] <- p_death
    }
    
    chr_last_tunnel <- v_prog_tunnel[n_tunnel_size]
    
    # From last progressed tunnel
    P_t[chr_last_tunnel, chr_last_tunnel] <- 1 - v_p_P_D[n_tunnel_size]
    
    P_t[chr_last_tunnel, "Death"] <- v_p_P_D[n_tunnel_size]
    
    # Death absorbing
    P_t["Death", "Death"] <- 1
    
    m_M_tunnels[t + 1, ] <- m_M_tunnels[t, ] %*% P_t
    rm(P_t)
    
  }
  # Create aggregated trace
  m_M_tunnels_sum  <- cbind(
    'Progression-free' = m_M_tunnels[, "Progression-free"],
    'Progressed'       = rowSums(m_M_tunnels[, 2:(n_tunnel_size + 1)]),
    'Death'            = m_M_tunnels[, "Death"])
  
  # df_M_tunnels_sum <- as.data.frame(m_M_tunnels_sum)
  
  m_M_tunnels_sum <- cbind(time = x$v_time, m_M_tunnels_sum) 
  
  # df_calib <- data.frame(time = x$v_time,
  #                        OS   = 1 - m_M_tunnels_sum[,"Death"],
  #                        PFS  = m_M_tunnels_sum[,"Progression-free"])
  
  # Life expectancy of the cohort (in cycle-length)
  life_expectancy <- sum(1 - m_M_tunnels_sum[,"Death"])
  
  # Return outputs
  return(list(
    # a_P             = a_P_tunnels,
    m_M             = m_M_tunnels_sum, 
    # df_calib        = df_calib,
    v_OS            = 1 - m_M_tunnels_sum[,"Death"],
    v_PFS           = m_M_tunnels_sum[,"Progression-free"],
    life_expectancy = life_expectancy))
  # })
}


#' Create transition rate
#'
#' \code{create_transition_rate} obtains a the transition rate between health states
#' @param n_cycles number of cycles to recreate.
#' @param distribution  distribution of the hazard rate. Default = exp.
#' @param param_1 required parameter (rate) in exponential, gompertz and gamma distributions. Required parameter (scale) in weibull, weibullPH, and log-logistic distributions. Required parameter (Mean Log) in log-normal distribution. Required parameter (Mu) in generalized gamma distribution.
#' @param param_2 required parameter (shape) in weibull, weibullPH, log-logistic, gompertz, and gamma distributions. Required parameter (SD Log) in log-normal distribution. Required parameter (Sigma) in generalized gamma distribution.
#' @param param_3 required parameter (Q) in generalized gamma distribution.
#' @return 
#' The estimated hazard rate is obtained in function of the number of cycles,
#' the selected distribution and the specified parameters of each specification. 
#' The hazard rate can be time-constant (with the exponential
#' distribution), or time varying (with any other distribution, and certain
#' combinations of parameters).
#' There will be cases where the value of the first element in the output is NaN
#' or infinite. If that occurs, the value of the second element in the output 
#' will be assigned to the value of the first
#' @export
create_transition_rate <- function(
    n_cycles     = NULL,
    v_time      = NULL,
    distribution = c("exp", "weibull","weibullPH", "gompertz", "gamma", "lnorm", "llogis","gengamma"), 
    param_1         = NULL, 
    param_2        = NULL, 
    param_3        = NULL) {
  # Error checking ----------------------------------------------------------- -
  # Check if the selected distribution is in the available set
  distribution <- match.arg(distribution)
  
  ## correct definition for n_cycles
  if (is.null(n_cycles) & is.null(v_time)) {stop("You have to provide either n_cycles or v_time to the function")}
  
  
  if (!is.null(n_cycles)) {
    stopifnot(
      "`n_cycles` must have length == 1"          = length(n_cycles) == 1,
      "`n_cycles` must be an integer"             = (n_cycles %% 1 == 0),
      "`n_cycles` must contain positive integers" = n_cycles >= 0)
  }
  
  if (!is.null(v_time)) {
    stopifnot(
      "`v_time` must have length > 0"                             = length(v_time) > 0,
      "All values in `v_time` must be greater than or equal to 0" = all(v_time >= 0))
  }
  
  ## Check that the parameters correspond to their distribution 
  if (distribution == "exp" & is.null(param_1)) {
    stop("The selected distribution needs to have defined a param_1 (rate) parameter")
  }
  if (distribution %in% c("weibull", "weibullPH", "llogis") & (is.null(param_1) | is.null(param_2))) {
    stop("The selected distribution needs to have defined param_1 (scale) and param_2 (shape) parameters")
  }
  if (distribution %in% c("gompertz", "gamma") & (is.null(param_1) | is.null(param_2))) {
    stop("The selected distribution needs to have defined param_1 (rate) and param_2 (shape) parameters")
  }
  if (distribution == "lnorm" & (is.null(param_1) | is.null(param_2))) {
    stop("The selected distribution needs to have defined param_1 (meanlog) and param_2 (sdlog) parameters")
  }
  if (distribution == "gengamma" & (is.null(param_1) | is.null(param_2) | is.null(param_3))) {
    stop("The selected distribution needs to have defined param_1 (mu), param_2 (sigma), and param_3 (Q) parameters")
  }
  
  ## Check that the arguments are compatible with each distribution 
  if (distribution == "exp" & !is.null(param_1)) {
    if (!is.numeric(param_1) | param_1 <= 0) {
      stop("The param_1 (rate) for exponential distribution must be a number greater than zero")
    } 
  }
  if (distribution %in% c("weibull", "weibullPH", "llogis") & !is.null(param_2) & !is.null(param_1)) {
    if (!is.numeric(c(param_2, param_1)) | param_2 <= 0 | param_1 <= 0) {
      stop("param_1 (Scale) and param_2 (shape) parameters must be numbers greater than zero")
    }
  }
  if (distribution == "gompertz" & !is.null(param_2) & !is.null(param_1)) {
    if (!is.numeric(c(param_2, param_1)) | param_1 <= 0) {
      stop("param_1 (rate) and param_2 (shape) parameters must be numbers, with param_1 (rate) greater than zero")
    }
  }
  if (distribution == "gamma" & !is.null(param_2) & !is.null(param_1)) {
    if (!is.numeric(c(param_2, param_1)) | param_2 <= 0 | param_1 <= 0) {
      stop("param_1 (rate) and param_2 (shape) parameters must be numbers greater than zero")
    }
  }
  if (distribution == "lnorm" & !is.null(param_1) & !is.null(param_2)) {
    if (!is.numeric(c(param_1, param_2)) | param_2 <= 0) {
      stop("param_1 (Meanlog) and param_2 (sdlog) parameters must be numbers, with param_2 (sdlog) greater than zero")
    }
  }
  if (distribution == "gengamma" & !is.null(param_1) & !is.null(param_2) & !is.null(param_3) ) {
    if (!is.numeric(c(param_1, param_2, param_3)) | param_2  <= 0) {
      stop("param_1 (Mu), param_2 (sigma), and param_3 (Q) parameters must be numbers, with param_2 (sigma) greater than zero")
    }
  }
  
  
  
  # Create vector of cycles 
  if (is.null(v_time)) { 
    v_time <- 0:n_cycles
  }
  
  # Obtain cumulative hazard based on selected distribution
  v_cum_haz <- switch(
    distribution,
    exp       = flexsurv::Hexp(x       = v_time, rate = param_1),
    weibull   = flexsurv::Hweibull(x   = v_time, shape = param_2,   scale = param_1),
    weibullPH = flexsurv::HweibullPH(x = v_time, shape = param_2,   scale = param_1),
    llogis    = flexsurv::Hllogis(x    = v_time, shape = param_2,   scale = param_1),
    gompertz  = flexsurv::Hgompertz(x  = v_time, shape = param_2,   rate = param_1),
    gamma     = flexsurv::Hgamma(x     = v_time, shape = param_2,   rate = param_1),
    lnorm     = flexsurv::Hlnorm(x     = v_time, meanlog = param_1, sdlog = param_2),
    gengamma  = flexsurv::Hgengamma(x  = v_time, mu = param_1,      sigma = param_2, Q = param_3)
  )
  
  # if (distribution == "exp") {
  # 
  #   v_cum_haz <- param_1 * v_time
  # 
  # 
  # } else if (distribution %in% c("weibull")) {
  # 
  #   # scale = param_1, shape = param_2
  #   v_cum_haz <- (v_time / param_1)^param_2
  # 
  # 
  # } else if (distribution %in% c("weibullph")) {
  # 
  #   # scale = param_1, shape = param_2
  #   v_cum_haz <- flexsurv::HweibullPH(
  #     x = v_time,
  #     shape = param_2,
  #     scale = param_1
  #     )
  #   
  # }else if (distribution == "gompertz") {
  # 
  #   # rate = param_1, shape = param_2
  #   v_cum_haz <- (param_1 / param_2) * (exp(param_2 * v_time) - 1)
  # 
  # 
  # } else if (distribution == "llogis") {
  # 
  #   # scale = param_1, shape = param_2
  #   v_cum_haz <- log(1 + (v_time / param_1)^param_2)
  # 
  # 
  # } else if (distribution == "lnorm") {
  # 
  #   # meanlog = param_1, sdlog = param_2
  #   v_time_safe <- pmax(v_time, 1e-12)
  # 
  #   S <- 1 - pnorm((log(v_time_safe) - param_1) / param_2)
  #   S[S < 1e-16] <- 1e-16  # numerical stability
  # 
  #   v_cum_haz <- -log(S)
  # 
  # 
  # } else if (distribution == "gamma") {
  # 
  #   # shape = param_2, rate = param_1
  #   # cumulative hazard = -log(1 - CDF)
  #   F <- pgamma(v_time, shape = param_2, rate = param_1)
  #   F[F > 1 - 1e-16] <- 1 - 1e-16
  # 
  #   v_cum_haz <- -log(1 - F)
  # 
  # 
  # } else if (distribution == "gengamma") {
  # 
  #   v_cum_haz <- flexsurv::Hgengamma(
  #     x = v_time,
  #     mu = param_1,
  #     sigma = param_2,
  #     Q = param_3
  #   )
  # 
  # } else {
  # 
  #   stop("Unsupported distribution")
  # }
  
  
  # v_diff_cum_haz <- c(0, diff(x = v_cum_haz))
  v_diff_cum_haz <- v_cum_haz[-1]-v_cum_haz[-length(v_cum_haz)]
  # diff(x = v_cum_haz)
  
  # Return vector of hazards
  return(v_diff_cum_haz)
}



# 03 Calibration functions ------------------------------------------------

#' Generate model outputs for calibration from a parameter set
#'
#' \code{calibration_out} computes model outputs to be used for calibration 
#' routines.
#'
#' @param m_params_calib Matrix containing sets of parameters that need to be calibrated.
#' @param l_params_all List with all parameters of the decision model.
#' @return 
#' A list with progression-free survival (DFS), and overall survival (OS)
#' @export
calibration_out <- function(m_params_calib, 
                            l_params_all,
                            model_type = "markov"){
  
  # Substitute values of calibrated parameters in base-case with 
  # calibrated values
  l_params_all <- update_param_list(l_params_all   = l_params_all, 
                                    params_updated = m_params_calib)
  
  # Run the Multi state Model
  l_out_stm <- threestate_model(l_params_all = l_params_all,
                                model_type    = model_type)
  
  # Epidemiological Outputs -------------------------------------------------- -
  
  # Progression-free survival
  v_PFS <- l_out_stm$v_PFS
  
  # Overall survival
  v_OS <- l_out_stm$v_OS
  
  
  # Assign time names
  names(v_OS) <- names(v_PFS) <- l_params_all$v_time
  
  
  # Return Output ------------------------------------------------------------ -
  
  # output list
  l_out <- list(v_PFS           = v_PFS,
                v_OS            = v_OS,
                m_M             = l_out_stm$m_M,
                # df_calib        = l_out_stm$df_calib,
                life_expectancy = l_out_stm$life_expectancy)
  
  return(l_out)
}



#' Generate calibration bounds
#' 
#' This function defines the upper and lower bounds of the parameters to
#' calibrate. These parameters must be present in the objects returned by
#' `load_params_all`.
#' This function is used inside `sample_uniform_lhs`, `sample.prior`,
#' `log_prior`, and `prior` functions.
#' If `l_params_all` (a list object) is defined in the global environment this
#' function can inherit the distributions defined for each transition in 
#' `l_params_init`.
#' 
#'
#' @return A data.table indicating the distribution of the transitions between 
#' health states and theof the calibrated parameters as well as their
#' lower and upper bounds.
#' @export
#'
#' @examples
#' l_params_init <- load_params_init(dist_PF_D    = "exp",
#'                                   dist_P_D     = "weibull",
#'                                   dist_PF_P    = "lnorm")
#' 
#' l_params_all <- load_params_all(l_params_init = l_params_init)
#' 
#' gen_bounds()
gen_bounds <- function() {
  
  #* Define vector indicating which parameters can have values <= 0
  v_param_ranges <- c(exp_1       = 0, # rate
                      weibull_1   = 0, # scale
                      weibull_2   = 0, # shape
                      weibullPH_1 = 0, # scale
                      weibullPH_2 = 0, # shape
                      gompertz_1  = 0, # rate
                      gompertz_2  = 1, # shape
                      gamma_1     = 0, # rate
                      gamma_2     = 0, # shape
                      lnorm_1     = 1, # meanlog
                      lnorm_2     = 0, # sdlog
                      llogis_1    = 0, # scale
                      llogis_2    = 0) # shape
  
  v_param_names <- c(exp_1       = "rate",
                     weibull_1   = "scale",
                     weibull_2   = "shape",
                     weibullPH_1 = "scale",
                     weibullPH_2 = "shape",
                     gompertz_1  = "rate",
                     gompertz_2  = "shape",
                     gamma_1     = "rate",
                     gamma_2     = "shape",
                     lnorm_1     = "meanlog",
                     lnorm_2     = "sdlog",
                     llogis_1    = "scale",
                     llogis_2    = "shape")
  
  #* Define data.table with possible ranges of distribution parameters
  #* - `lte_0` indicates the values that can take values <= 0
  dt_param_ranges <- data.table::data.table(dist_param = names(v_param_ranges),
                                            param_name = v_param_names,
                                            lte_0      = v_param_ranges)
  
  #* If `l_params_all` is defined in the global environment this function will 
  #* inherit the distributions defined in it.
  if (exists("l_params_all") == TRUE) {
    
    #* Extract distributions defined in `l_params_all` object 
    dist_PF_P <- l_params_all$dist_PF_P
    dist_PF_D <- l_params_all$dist_PF_D
    dist_P_D  <- l_params_all$dist_P_D
  } else {
    
    #* If `l_params_init` is not defined, use exponential distribution as 
    #* default
    dist_PF_D <- "exp"
    dist_P_D  <- "exp"
    dist_PF_P <- "exp"
  }
  
  dt_bounds <- data.table::data.table(
    # transition   = c("PF_D", "P_D", "PF_P"),
    # distribution = c(dist_PF_D, dist_P_D, dist_PF_P)
    transition   = c("PF_P", "PF_D",  "P_D"),
    distribution = c(dist_PF_P, dist_PF_D,  dist_P_D)
    )
  
  dt_bounds[, n_param := fifelse(test = distribution == "exp", yes = 1, no = 2)]
  
  #* repeat rows based on value of `n_param`
  dt_bounds_exp <- dt_bounds[rep(1:.N, n_param)]
  
  #* Add parameter ID and remove n_param column
  dt_bounds_exp[, id_param := 1:.N, by = transition]
  
  # create new column joining the distribution and the param ID
  dt_bounds_exp[, dist_param := paste0(distribution, "_", id_param)]
  
  # Add range information to all parameters of every distribution
  dt_bounds_exp <- merge.data.table(x = dt_bounds_exp, 
                                    y = dt_param_ranges, 
                                    by = "dist_param",
                                    sort = F)
  
  # Remove unused columns
  dt_bounds_exp[, `:=`(n_param    = NULL,
                       dist_param = NULL)]
  
  # Add
  dt_bounds_exp[, parameter := paste0("param_", id_param, "_", transition)]
  
  
  return(dt_bounds_exp[])
}


#* This version of the function is used inside load_params_all() to 
#* retrieve the data.table with the names of the arguments of every 
#* distribution.
gen_bounds_2 <- function(dist_PF_D, dist_P_D, dist_PF_P) {
  
  #* Define vector indicating which parameters can have values <= 0
  v_param_ranges <- c(exp_1       = 0, # rate
                      weibull_1   = 0, # scale
                      weibull_2   = 0, # shape
                      weibullPH_1 = 0, # scale
                      weibullPH_2 = 0, # shape
                      gompertz_1  = 0, # rate
                      gompertz_2  = 1, # shape
                      gamma_1     = 0, # rate
                      gamma_2     = 0, # shape
                      lnorm_1     = 1, # meanlog
                      lnorm_2     = 0, # sdlog
                      llogis_1    = 0, # scale
                      llogis_2    = 0) # shape
  
  v_param_names <- c(exp_1       = "rate",
                     weibull_1   = "scale",
                     weibull_2   = "shape",
                     weibullPH_1 = "scale",
                     weibullPH_2 = "shape",
                     gompertz_1  = "rate",
                     gompertz_2  = "shape",
                     gamma_1     = "rate",
                     gamma_2     = "shape",
                     lnorm_1     = "meanlog",
                     lnorm_2     = "sdlog",
                     llogis_1    = "scale",
                     llogis_2    = "shape")
  
  #* Define data.table with possible ranges of distribution parameters
  #* - `lte_0` indicates the values that can take values <= 0
  dt_param_ranges <- data.table::data.table(dist_param = names(v_param_ranges),
                                            param_name = v_param_names,
                                            lte_0      = v_param_ranges)
  
  dt_bounds <- data.table::data.table(
    transition   = c("PF_D", "P_D", "PF_P"),
    distribution = c(dist_PF_D, dist_P_D, dist_PF_P))
  
  dt_bounds[, n_param := fifelse(test = distribution == "exp", yes = 1, no = 2)]
  
  #* repeat rows based on value of `n_param`
  dt_bounds_exp <- dt_bounds[rep(1:.N, n_param)]
  
  #* Add parameter ID and remove n_param column
  dt_bounds_exp[, id_param := 1:.N, by = transition]
  
  # create new column joining the distribution and the param ID
  dt_bounds_exp[, dist_param := paste0(distribution, "_", id_param)]
  
  # Add range information to all parameters of every distribution
  dt_bounds_exp <- merge.data.table(x = dt_bounds_exp, 
                                    y = dt_param_ranges, 
                                    by = "dist_param",
                                    sort = F)
  
  # Remove unused columns
  dt_bounds_exp[, `:=`(n_param    = NULL,
                       dist_param = NULL)]
  
  # Add
  dt_bounds_exp[, parameter := paste0("param_", id_param, "_", transition)]
  
  return(dt_bounds_exp[])
}


#' Sample from prior distributions of calibrated parameters
#'
#' \code{sample.prior} generates a sample of parameter sets from their prior 
#' distribution.
#' @param n_samp Number of samples.
#' @param v_param_names Vector with parameter names.
#' @param v_ub Vector with lower bounds for each parameter.
#' @param v_lb Vector with upper bounds for each parameter.
#' @return 
#' A matrix with a number of columns equal to the number of \code{v_param_anames}  
#' and \code{n_samp} rows. Each row corresponds to a parameter set sampled from 
#' their prior distributions
#' @examples 
#' 
#' m_params <- sample.prior(n_samp = 5)
#' @export
sample.prior <- function(n_samp){
  
  # Obtain bounds of calibrated parameters
  dt_calib_params <- gen_bounds()
  
  # Get number of parameters
  n_param <- nrow(dt_calib_params)
  
  # Get parameter names
  v_param_names <- dt_calib_params$parameter
  
  # Identify parameters that have values lower than, or equal to (lte), 0
  v_params_lte_0 <- dt_calib_params[lte_0 == 1, parameter]
  
  # Define empty matrix to store sampled values
  m_samp <- matrix(data = 0,
                   nrow = n_samp,
                   ncol = n_param,
                   dimnames = list(1:n_samp, v_param_names))
  
  for (i in 1:n_param) { # i <- 1
    
    if (v_param_names[i] %in% v_params_lte_0) {
      # If param contains values <= 0, sample from normal distribution
      
      #m_samp[, i] <- rnorm(n = n_samp, mean = 0, sd = 100) #original
      m_samp[, i] <- rnorm(n = n_samp, mean = 0, sd = 10) #new
      
    } else {
      # If param contains values > 0, sample from half-t distribution
      
      #m_samp[, i] <- extraDistr::rht(n = n_samp, nu = 1, sigma = 2) #original
      m_samp[, i] <- extraDistr::rht(n = n_samp, nu = 1, sigma = 1) #new
      
    }
  }
  return(m_samp)
}

acor2cov <- function(acor, sd){
  n_y <- length(acor)
  covar <- matrix(0, n_y, n_y)
  for (i in 0:(n_y - 1)) {
    covar[i + 1, (i + 1):n_y] <- acor[1:(n_y - i)]
  }
  covar <- covar + t(covar)
  diag(covar) <- 1
  covar <- cor2cov(covar, sd)
}

corr.ar <- function(p, rho){
  ### Multinomial distribution correlation matrix
  # Source: http://www.ism.ac.jp/editsec/aism/pdf/058_2_0311.pdf
  n.y <- length(p)
  times <- 1:n.y
  H <- abs(outer(times, times, "-"))
  corr.mat <- rho^H
  return(corr.mat)
}

cor2cov = function(corMat, varVec) {
  # H. Seltman, May 2014
  
  # Goal: convert a correlation matrix and variance vector
  #       into the corresponding covariance matrix
  #
  # Input:
  #   'corMat' is a square matrix with 1's on the diagonal
  #      and valid correlations on the off-diagonal
  #   'varVec' is a valid variance vector, with length
  #      matching the dimension of 'covMat'.  A single
  #      row or single column matrix is also allowed.
  # Output:
  #   the covariance matrix
  #
  # A warning is given if the covariance matrix is not
  #   positive definite.
  #
  # test the input
  if (!is.matrix(corMat)) stop("'corMat must be a matrix")
  n = nrow(corMat)
  if (ncol(corMat) != n) stop("'corMat' must be square")
  if (mode(corMat) != "numeric") stop("'corMat must be numeric")
  if (mode(varVec) != "numeric") stop("'varVec must be numeric")
  if (!is.null(dim(varVec))) {
    if (length(dim(varVec)) != 2) stop("'varVec' should be a vector")
    if (any(dim(varVec) == 1)) stop("'varVec' cannot be a matrix")
    varVec = as.numeric(varVec) # convert row or col matrix to a vector
  }
  if (!all(diag(corMat) == 1)) stop("correlation matrices have 1 on the diagonal")
  if (any(corMat < -1 | corMat > +1))
    stop("correlations must be between -1 and 1")
  if (any(varVec <= 0)) stop("variances must be non-negative")
  if (length(varVec) != n) stop("length of 'varMat' does not match 'corMat' size")
  
  # Compute the covariance
  sdMat = diag(sqrt(varVec))
  rtn = sdMat %*% corMat %*% t(sdMat)
  if (det(rtn) <= 0) warning("covariance matrix is not positive definite")
  return(rtn)
}


#' Evaluate log-prior of calibrated parameters
#'
#' \code{log_prior} computes a log-prior value for one (or multiple) parameter 
#' set(s) based on their prior distributions.
#' @param m_params Matrix (or vector) of model parameters.
#' @param v_param_names Vector with parameter names.
#' @param v_ub Vector with lower bounds for each parameter.
#' @param v_lb Vector with upper bounds for each parameter.
#' @return 
#' A scalar (or vector) with log-prior values.
#' @examples
#' m_params <- sample.prior(n_samp = 5)
#' 
#' log_prior(m_params = m_params)
#' @export
log_prior <- function(m_params){
  
  # Obtain bounds of calibrated parameters
  dt_calib_params <- gen_bounds()
  
  # Get number of parameters
  n_param <- nrow(dt_calib_params)
  # Get number of samples
  n_samp <- nrow(m_params)
  # Get parameter names
  v_param_names <- dt_calib_params$parameter
  
  # Identify parameters that have values lower than, or equal to (lte), 0
  v_params_lte_0 <- dt_calib_params[lte_0 == 1, parameter]
  
  # Identify parameters that have values lower than or equal to zero
  v_log_params <- which(dt_calib_params$lte_0 == 0)
  
  # Initialize vector containing log-likelihood values from prior distribution
  v_log_prior <- rep(0, n_samp)
  
  #* Loop to calculate log-likelihood values and fill *v_log_prior* vector
  for (i in 1:n_param) { # i <- 1
    
    if (v_param_names[i] %in% v_params_lte_0) {
      #* Use density from *normal distribution* for params with values <= 0
      v_log_prior <- v_log_prior + dnorm(x    = m_params[, i],
                                         mean = 0,
                                         sd   = 100,
                                         log  = TRUE)
    } else {
      #* Use density from *half-t distribution* for params with values > 0
      v_log_prior <- v_log_prior + extraDistr::dht(x     = m_params[, i],
                                                   nu    = 1,
                                                   sigma = 2,
                                                   log   = TRUE)
    }
  }
  return(v_log_prior)
}


#' Evaluate prior of calibrated parameters
#'
#' \code{prior} computes a prior value for one (or multiple) parameter set(s).
#' @param m_params Matrix (or vector) of model parameters 
#' @return 
#' A scalar (or vector) with prior values.
#' @examples
#' m_params <- sample.prior(n_samp = 5)
#' 
#' prior(m_params = m_params, v_lb = v_lb, v_ub = v_ub)
#' @export
prior <- function(m_params){ 
  
  v_prior <- exp(log_prior(m_params = m_params)) 
  
  return(v_prior)
}



#' Log-likelihood function for a parameter set
#'
#' \code{log_lik} computes a log-likelihood value for one (or multiple) 
#' parameter set(s).
#'
#' @param m_params Matrix (or vector) of model parameters.
#' @param l_params_all List with all parameters of the decision model. 
#' @return 
#' A scalar (or vector) with log-likelihood values.
#' @importFrom stats dnorm dunif quantile qunif rbeta rgamma sd
#' @examples 
#' 
#' m_params <- sample.prior(n_samp = 50)
#' 
#' log_lik(m_params = m_params)
#' @export
log_lik <- function(m_params){ 
  
  if (is.null(dim(m_params))) { 
    # If vector, change to matrix
    m_params <- t(m_params) 
  }
  
  # Define number of calibration parameter sets
  n_samp <- nrow(m_params)
  
  # Define target names
  v_target_names <- c("PFS", "OS")
  
  # Number of targets
  n_target <- length(v_target_names)
  
  # Define matrix to save log likelihoods per target
  m_log_lik <- matrix(data = 0, nrow = n_samp, ncol = n_target) 
  
  colnames(m_log_lik) <- v_target_names
  
  v_log_lik_overall <- vector(mode = "numeric", length = n_samp) 
  
  for (j in 1:n_samp) {
    
    # j <- 1
    # j <- 2
    # j <- 3
    
    jj <- tryCatch(
      expr = {
        ###   Run model for parameter set "m_params[j, ]" ###
        l_model_res <- calibration_out(m_params_calib = m_params[j, ],
                                       l_params_all   = l_params_all)
        
        ## Filter the model outputs to match target times
        v_OS_select  <- names(l_model_res$v_OS) %in% as.character(v_target_time)
        v_PFS_select <- names(l_model_res$v_PFS) %in% as.character(v_target_time)
        
        v_OS_mod_out  <- l_model_res$v_OS[v_OS_select]
        v_PFS_mod_out <- l_model_res$v_PFS[v_PFS_select]
        
        ###  Calculate log-likelihood of model outputs to targets  ###
        ## TARGET TYPE 1: Progression-free survival ("PFS")
        ## Normal log-likelihood  (assuming no correlation)
        m_log_lik[j, "PFS"] <- sum(
          dnorm(x    = v_PFS_mod_out[-1],
                mean = l_params_all$v_targets_PFS[-1],
                sd   = l_params_all$v_targets_se_PFS[-1],
                log  = T)
        )

        ## TARGET TYPE 2: Overall survival ("OS")
        ## Normal log-likelihood  (assuming no correlation)
        m_log_lik[j, "OS"] <- sum(
          dnorm(x    = v_OS_mod_out[-1],
                mean = l_params_all$v_targets_OS[-1],
                sd   = l_params_all$v_targets_se_OS[-1],
                log  = T)
        )
        
        # OVERALL
        # User can give different targets specific weights 
        # (currently unweighted)
        v_weights <- rep(1, n_target)
        
        # v_weights[length(v_weights)] <- 5
        
        # weighted sum
        v_log_lik_overall[j] <- m_log_lik[j, ] %*% v_weights
      }, 
      error = function(e) NA) 
    
    # Assign -Inf is the model generates an error
    if (is.na(jj)) { v_log_lik_overall[j] <- -Inf }
  } ## End loop over sampled parameter sets
  
  ## return GOF
  return(v_log_lik_overall)
}

#' Parallel evaluation of log-likelihood function for a sets of parameters
#'
#' \code{log_lik_par} computes a log-likelihood value for one (or multiple) 
#' parameter set(s) using parallel computation.
#'
#' @param m_params Vector (or matrix) of model parameters.
#' @param l_params_all List with all parameters of the decision model. 
#' @return 
#' A scalar (or vector) with log-likelihood values.
#' @importFrom stats dnorm dunif quantile qunif rbeta rgamma sd
#' @import doParallel
#' @examples 
#' 
#' m_params <- sample.prior(n_samp = 2)
#' 
#' log_lik_par(m_params = m_params)
#' 
#' @export
log_lik_par <- function(m_params, l_params_all,
                        ...) { 
  if(is.null(dim(m_params))) { # If vector, change to matrix
    m_params <- t(m_params) 
  }
  
  n_samp <- nrow(m_params)
  
  ### Get OS
  os <- darthtools::get_os()
  
  no_cores <- parallel::detectCores() - 1
  
  print(paste0("Parallelized Likelihood calculations on ", os, " using ", no_cores, " cores"))
  
  n_time_init_likpar <- Sys.time()
  
  if(os == "macosx"){
    # Initialize cluster object
    cl <- parallel::makeForkCluster(no_cores) 
    doParallel::registerDoParallel(cl)
    v_llk <- foreach::foreach(i = 1:n_samp, .combine = c) %dopar% {
      log_lik(m_params[i, ], l_params_all) # i = 1
    }
    n_time_end_likpar <- Sys.time()
  }
  
  if(os == "windows"){
    # Initialize cluster object
    cl <- parallel::makeCluster(no_cores)
    doParallel::registerDoParallel(cl)
    opts <- list(attachExportEnv = TRUE)
    v_llk <- foreach::foreach(i = 1:n_samp, .combine = c,
                              .export = ls(globalenv()),
                              .packages=c(),
                              .options.snow = opts) %dopar% {
                                log_lik(m_params[i, ], ...)
                              }
    n_time_end_likpar <- Sys.time()
  }
  
  if(os == "linux"){
    # Initialize cluster object
    cl <- parallel::makeCluster(no_cores)
    doMC::registerDoMC(cl)
    v_llk <- foreach::foreach(i = 1:n_samp, .combine = c) %dopar% {
      log_lik(m_params[i, ], ...)
    }
    n_time_end_likpar <- Sys.time()
  }
  
  parallel::stopCluster(cl)
  n_time_total_likpar <- difftime(n_time_end_likpar, n_time_init_likpar, 
                                  units = "hours")
  print(paste0("Runtime: ", round(n_time_total_likpar, 2), " hrs."))
  #-# Try this: # PO
  rm(cl)        # PO
  gc()          # PO
  #-#           # PO
  return(v_llk)
}

#' Likelihood
#'
#' \code{likelihood} computes a likelihood value for one (or multiple) 
#' parameter set(s).
#'
#' @param m_params Matrix (or vector) of model parameters. 
#' @return 
#' A scalar (or vector) with likelihood values.
#' @examples
#' m_params <- sample.prior(n_samp = 2)
#' 
#' likelihood(m_params = m_params)
#' @export
likelihood <- function(m_params, 
                       parallel = FALSE){ 
  
  if (parallel == FALSE) {
    v_like <- exp(log_lik(m_params = m_params)) 
  }
  
  if (parallel == TRUE) {
    v_like <- exp(log_lik_par(m_params = m_params)) 
  }
  
  return(v_like)
}


#' Evaluate log-posterior of calibrated parameters
#'
#' \code{log_post} Computes a log-posterior value for one (or multiple) 
#' parameter set(s) based on the simulation model, likelihood functions and 
#' prior distributions.
#' @param m_params Vector (or matrix) of model parameters 
#' @return 
#' A scalar (or vector) with log-posterior values.
#' @examples 
#' log_post(m_params = sample.prior(n_samp = 2))
#' @export
log_post <- function(m_params) { 
  
  v_lpost <- log_prior(m_params) + log_lik(m_params)
  
  return(v_lpost) 
}


#' Evaluate posterior of calibrated parameters
#'
#' \code{posterior} computes a posterior value for one (or multiple) parameter 
#' set(s).
#' @param m_params Vector (or matrix) of model parameters 
#' @return 
#' A scalar (or vector) with posterior values.
#' @examples
#' posterior (m_params = sample.prior(n_samp = 5))
#' @export
posterior <- function(m_params) { 
  
  v_posterior <- exp(log_post(m_params)) 
  
  return(v_posterior)
}



# 04 Validation functions -------------------------------------------------


#' Check for repeated values in MAP parameter list
#'
#' @param l_MAP_params A list containing vectors of parameters.
#'
#' @returns A logical value, indicating if all the values per object in the list are repeated (TRUE) or not (FALSE).
#' @export
check_MAP_list <- function(l_MAP_params) {
  
  check_vector <- function(v_params) {
    all(v_params[1] == v_params)
  }
  
  sapply(X = l_MAP_params, FUN = check_vector)
}



#' Summarize posterior output
#'
#' \code{data_summary} is used to to calculate the mean, standard deviation and 
#' 95% credible interval.
#' @param data Data frame.
#' @param varname Name of a column containing the variable.
#' @param groupnames Vector of column names to be used as grouping variables.
#' @return 
#' A data frame containing the posterior output.
#' @export
data_summary <- function(data, varname, groupnames){
  summary_func <- function(x, col){
    c(mean = mean(x[[col]], na.rm = TRUE),
      median = quantile(x[[col]], probs = 0.5, names = FALSE),
      sd = sd(x[[col]], na.rm=TRUE),
      lb = quantile(x[[col]], probs = 0.025, names = FALSE),
      ub = quantile(x[[col]], probs = 0.975, names = FALSE))
  }
  data_sum <- plyr::ddply(data, groupnames, .fun = summary_func, 
                          varname)
  data_sum <- plyr::rename(data_sum, c("mean" = varname))
  return(data_sum)
}


bootflexsurv <- function (x, 
                          t, 
                          start, 
                          X=NULL, 
                          type = "survival", 
                          B = 1000) {
  
  fn <- flexsurv:::summary_fns(x, type)
  if (all(is.na(x$cov)) || (B == 0)) 
    ret <- array(NA, dim = c(2, length(t)))
  else {
    sim <- flexsurv:::normboot.flexsurvreg(x, B, X = X, tidy = TRUE)
    args <- list(t = rep(t, each = B), start = rep(start, 
                                                   each = B))
    args <- c(args, as.list(as.data.frame(sim))[x$dlist$pars])
    for (j in seq_along(x$aux)) args[[names(x$aux)[j]]] <- x$aux[[j]]
    ret <- do.call(fn, args)
    ret <- matrix(ret, nrow = B)
    
  }
  t(ret)
}



# 05 Forecasting functions ------------------------------------------------

get_calib_95_IQR <- function(m_OS_calib,
                             m_PFS_calib) {
  
  v_probs = c(0.025, 0.5, 0.975)
  v_times <- as.numeric(colnames(m_OS_calib))
  
  # Compute Interquartile ranges (IQR) among different model realizations
  m_OS_95_IQR  <- matrixStats::colQuantiles(x = m_OS_calib,  probs = v_probs)
  m_PFS_95_IQR <- matrixStats::colQuantiles(x = m_PFS_calib, probs = v_probs)
  
  
  df_95_IQR <- dplyr::bind_rows(OS  = dplyr::as_tibble(m_OS_95_IQR),
                                PFS = dplyr::as_tibble(m_PFS_95_IQR),
                                .id = "type")
  
  df_95_IQR_1 <- df_95_IQR %>% 
    mutate(time = rep(v_times, 2), .after = 1) %>% 
    rename(lb_95  = `2.5%`,
           median = `50%`,
           ub_95  = `97.5%`)
  
  return(df_95_IQR_1)
}

plot_forecasting <- function(df_95_IQR,
                             df_targets,
                             n_breaks_x) {
  
  # Update format of targets data set
  df_targets_plt <- df_targets %>% 
    mutate(Source = "Calibration target") %>% 
    select(Source, 
           # type = target,
           type,
           time = time, 
           median = survival, 
           se,
           lb_95 = lower_95_CI,
           ub_95 = upper_95_CI)
  
  # Plot forecasted results compared to calibration targets
  ggplot(
    data = filter(df_95_IQR),
    mapping = aes(x = time, 
                  y     = median,
                  ymin  = lb_95,
                  ymax  = ub_95,
                  color = type,
                  fill  = type,
                  group = type)) + 
    theme_bw(base_size = 21) +
    geom_line(alpha = 0.5) +
    geom_ribbon(alpha = 0.3, color = NA) + 
    geom_errorbar(data = df_targets_plt) +
    geom_point(data = df_targets_plt, size = 1) +
    geom_vline(xintercept = max(df_targets_plt$time), linetype = "longdash", linewidth = 0.8) +
    scale_x_continuous(breaks = scales::pretty_breaks(n = 5)) +
    scale_y_continuous(breaks = seq(0, 1, 0.2)) +
    theme(legend.position = "bottom") + 
    coord_cartesian(ylim = c(0, 1)) +
    labs(y = "Survival",
         x = "Time", 
         color = "Group: ",
         fill  = "Group: ") +
    facet_wrap(~type)
  
}


plot_cohort_trace <- function(l_model_output) {
  
  v_state_names <- c("Progression-free", "Progressed", "Death")
  
  # Prepare cohort trace data set for plotting
  df_m_M_plt <- l_model_output$m_M %>% 
    as.data.frame() %>% 
    tidyr::pivot_longer(cols = all_of(v_state_names),
                        names_to = "state",
                        values_to = "prop") %>% 
    mutate(state = factor(x = state, levels = v_state_names, ordered = T))
  
  
  # Forecasted cohort trace using MAP parameter set
  ggplot(data = df_m_M_plt,
         mapping = aes(x     = time, 
                       y     = prop, 
                       color = state)) + 
    theme_bw(base_size = 21) +
    geom_line(linewidth = 0.9) +
    scale_x_continuous(breaks = scales::pretty_breaks(n = 5)) +
    scale_y_continuous(breaks = seq(0, 1, 0.2)) +
    scale_color_brewer(palette = "Set2") +
    theme(legend.position = "bottom") + 
    coord_cartesian(ylim = c(0, 1)) + 
    labs(x = "Time",
         y = "Cohort proportion",
         color = "State: ")
  
}