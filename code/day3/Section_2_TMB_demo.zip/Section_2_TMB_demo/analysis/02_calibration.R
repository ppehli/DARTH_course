#* Title: 02_calibration
#* 
#* Code function:
#*    This script *calibrates* the three-state model given a set of survival
#*    curves using a Bayesian approach with the 
#*    Incremental Mixture Importance Sampling (IMIS) algorithm
#*    
#*    #* Manual specifications based on the trial data you'd like to calibrate are required in:
#*    *section 01.04 * - specify intervention
#*    *section 02.01 * - specify calibration parameters
#* 
#* Authors: 
#* - David U. Garibay-Treviño and Fernando Alarid-Escudero on behalf of the DARTH work group


# 01 Initial Setup --------------------------------------------------------

## 01.01 Clean environment ------------------------------------------------

remove(list = ls())
gc()

## 01.02 Load libraries ----------------------------------------------------

# Install packages from CRAN (if required) and load packages
if (!require('pacman')) install.packages('pacman'); library(pacman)
p_load("tidyverse", "scales", "remotes", "IMIS", "data.table", "GGally")

# remotes::install_github(repo = "cran/IMIS") #unhide if installing IMIS package for the first time

## 01.03 Load functions ----------------------------------------------------

source("Section_2_TMB_demo/R/multi-state-calibration-functions.R")

# 01.04 Specifications ----------------------------------------------------

# Define seed for reproducibility
seed <- 123

# Define the number of maximum iterations in the IMIS calibration algorithm
n_max_IMIS_iter <- 100

# Number of parameter samples to obtain from the calibrated posterior distribution 
# in IMIS
n_resamp <- 1000

# Save outputs?
save_out <- TRUE

# 02 Execute calibration algorithm ----------------------------------------

## 02.01 Specify calibration parameters ------------------------------------

#* - *dt_base* Data set containing calibration targets (generated in script 
#*             `analysis/01_define_targets.R`)
#* - *v_time* Vector of times used in the model (i.e., used to define cycle length)
#* - *v_target_time* Vector of times used as calibration targets

dt_base <- data.table::fread(file = "Section_2_TMB_demo/data-raw/TMB_less/KM_targets.csv")


#* Model time (the cycle length may differ from the target time, but the model
#* time must match the target times)
model_cycle_length <- 1

v_time <- seq(from = 0, to = 18, by = model_cycle_length)

# Target time
v_target_time <- seq(from = 0, to = 18, by = 3)
# v_target_time <- c(0, 3, 9, 18)



#* Define distribution used to model transitions between health states
#* Available distributions: "exp", "weibull","weibullPH", "gompertz", "gamma", "lnorm", "llogis"

# # Using all quarterly targets
# dist_PF_P      <- "weibullPH"
# dist_PF_D      <- "exp"
# dist_P_D       <- "llogis"

# Using selected targets
dist_PF_P      <- "llogis"
dist_PF_D      <- "gamma"
dist_P_D       <- "llogis"


#* Define model parameters used in calibration
#* *load_params_all()* is defined in script `R/multi-state-calibration-functions.R`
l_params_all <- load_params_all(intervention       = "TMB_less",
                                v_time             = v_time,
                                model_cycle_length = model_cycle_length,
                                v_target_time      = v_target_time,
                                dt_base            = dt_base,
                                dist_PF_P          = dist_PF_P,
                                dist_PF_D          = dist_PF_D,
                                dist_P_D           = dist_P_D)

# 03 Run IMIS algorithm ------------------------------------------------

#*  *Bayesian calibration using IMIS*
#* IMIS needs three functions defined in the global environment: 
#* - `sample.prior()`
#* - `prior()`, and
#* - `likelihood()`
#* 
#* These functions are defined in the script `R/multi-state-calibration-functions.R`. They
#* can be loaded to the global environment by sourcing that file 
#* (i.e., executing `source("R/multi-state-calibration-functions.R")`)

#* The values that are sampled in `m_params`depend on the distributions defined 
#* in `l_params_all` (i.e., the distribution names of dist_PF_D, dist_P_D, and 
#* dist_PF_P),
#* 
#* `l_params_all` must be defined in the global environment

set.seed(seed)
m_params     <- sample.prior(n_samp = 5)
set.seed(NULL)


v_prior      <- prior(m_params = m_params)
v_likelihood <- likelihood(m_params = m_params)


# # To check parameters' distribution
# summary(m_params)
# Hmisc::hist.data.frame(as.data.frame(m_params), nclass = 30)
# matrixStats::colQuantiles(x = m_param_samp, probs = c(0.025, 0.5, 0.975))


set.seed(seed)
l_fit_imis <- IMIS::IMIS(B        =  1500,      # incremental sample size at each iteration of IMIS
                         B.re     =  n_resamp,  # desired posterior sample size
                         number_k =  n_max_IMIS_iter, # maximum number of iterations in IMIS
                         D        =  0)         
set.seed(NULL)

# beepr::beep() #unhide this if you'd like R to sound when the IMIS is done

# Obtain posterior
m_calib_post <- l_fit_imis$resample

# Obtain vector of marginal likelihoods from IMIS iterations
v_marg_like <- l_fit_imis$stat[, 1]


# Make quick convergence check
stopifnot(
  "The calibration did not converge" = length(v_marg_like) > sum(is.na(v_marg_like)) 
)

# Save the Marginal Likelihood value from the final IMIS iteration
n_marg_lik <- tail(na.omit(v_marg_like), 1) 


## 03.01 Check posterior distribution ------------------------------------

### Compute posterior mean
v_calib_post_mean <- colMeans(m_calib_post)

### Compute posterior median and 95% credible interval
m_calib_post_95cr <- matrixStats::colQuantiles(m_calib_post, 
                                               probs = c(0.025, 0.5, 0.975))

### Compute likelihood of posterior values
v_calib_post <- exp(log_post(m_calib_post))

### Compute maximum-a-posteriori (MAP) as the mode of the sampled values
v_calib_post_map  <- m_calib_post[which.max(v_calib_post), ]

# Define vector of transition levels (for plotting)
transition_levels <- c("PF_P", "PF_D", "P_D")

df_calib_post_map <- data.frame(Parameter = names(v_calib_post_map),
                                value = v_calib_post_map,
                                row.names = NULL) %>% 
  mutate(transition = case_when(str_detect(Parameter, "PF_P") ~ "PF_P",
                                str_detect(Parameter, "PF_D") ~ "PF_D",
                                str_detect(Parameter, "P_D")  ~ "P_D"),
         param_type = case_when(str_detect(Parameter, "param_1") ~ "param_1",
                                str_detect(Parameter, "param_2") ~ "param_2",
                                str_detect(Parameter, "param_3") ~ "param_3"),
         transition = factor(transition, levels = transition_levels, ordered = T),
         param_type = factor(param_type, levels = c("param_1", "param_2", "param_3")))


# 04 Plotting -----------------------------------------------------------


### Plot the 1000 draws from the posterior
gg_post_pairs_corr <- GGally::ggpairs(
  data = data.frame(m_calib_post),
  upper = list(continuous = GGally::wrap("cor", color = "black", size = 5)),
  diag  = list(continuous = GGally::wrap("barDiag", alpha = 0.8)),
  lower = list(continuous = GGally::wrap("points", alpha = 0.3,size = 0.7))) +
  theme_bw(base_size = 18) +
  theme(axis.title.x     = element_blank(),
        axis.text.x      = element_text(size = 14),
        axis.title.y     = element_blank(),
        axis.text.y      = element_blank(),
        axis.ticks.y     = element_blank(),
        strip.background = element_rect(fill = "white", color = "white"),
        strip.text       = element_text(hjust = 0))

gg_post_pairs_corr


### Plot the 1000 draws from the posterior with marginal histograms
m_samp_prior <- sample.prior(n_resamp)

df_samp_prior <- reshape2::melt(
  data = cbind(PDF = "Prior", as.data.frame(m_samp_prior)), 
  variable.name = "Parameter",
  id.vars = "PDF")

df_samp_post_imis <- reshape2::melt(
  data = cbind(PDF = "Posterior IMIS", as.data.frame(m_calib_post)),
  variable.name = "Parameter",
  id.vars = "PDF")

df_samp_prior_post <- bind_rows(df_samp_prior, 
                                df_samp_post_imis) %>%
  mutate(transition = case_when(str_detect(Parameter, "PF_P") ~ "PF_P",
                                str_detect(Parameter, "PF_D") ~ "PF_D",
                                str_detect(Parameter, "P_D")  ~ "P_D"),
         param_type = case_when(str_detect(Parameter, "param_1") ~ "param_1",
                                str_detect(Parameter, "param_2") ~ "param_2",
                                str_detect(Parameter, "param_3") ~ "param_3"),
         transition = factor(transition, levels = transition_levels, ordered = T),
         param_type = factor(param_type, levels = c("param_1", "param_2", "param_3")),
         Parameter = factor(Parameter)) %>%
  as_tibble()


# Find 95% CI of the posterior distribution
df_post_bounds <- df_samp_prior_post %>%
  filter(PDF == "Posterior IMIS") %>%
  group_by(Parameter, transition, param_type) %>%
  summarise(lb_95 = quantile(value, 0.025),
            ub_95 = quantile(value, 0.975),
            .groups = "drop")

# Add posterior bounds to original data
df_samp_prior_post <- left_join(x = df_samp_prior_post,
                                y = df_post_bounds,
                                by = c("Parameter", "transition", "param_type"))

# Generate object to define label-specific x-axis limits
x_scales <- purrr::pmap(
  df_post_bounds,
  function(Parameter, transition, param_type, lb_95, ub_95) {
    rlang::new_formula(
      rlang::expr(Parameter ==!! Parameter & transition == !!transition & param_type == !!param_type),
      scale_x_continuous(limits = c(lb_95, ub_95), n.breaks = 6)
    )
  }
)


gg_post_imis <- ggplot(data    = df_samp_prior_post,
                       mapping = aes(x = value, 
                                     fill = PDF)) +
  theme_bw(base_size = 16) +
  geom_density(alpha = 0.5) +
  geom_vline(data = df_calib_post_map, 
             mapping = aes(xintercept = value),
             linetype = "dashed") +
  labs(caption = "The vertical dotted line represents the Maximum-a-Posteriori") +
  theme(legend.position = "bottom",
        axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank()) +
  ggh4x::facet_grid2(rows = vars(transition),
                     cols = vars(param_type),
                     scales = "free",
                     independent = "all") +
  ggh4x::facetted_pos_scales(x = x_scales)

gg_post_imis

# 05 Save calibration outputs ---------------------------------------------

if (save_out == TRUE) {
  # Register date and time to save outputs
  # Format of date time: YYY_MM_DD_HH_mm
  chr_datetime <- format(Sys.time(), "%Y_%m_%d_%Hh%Mm")
  
  path_save <- paste0("Section_2_TMB_demo/output/TMB_less/calib_", chr_datetime)
  
  # Create a folder to store calibration results
  dir.create(path = path_save)
  
}

## 05.01 Save plots --------------------------------------------------------

if (save_out == TRUE) {
  
  ggsave(plot = gg_post_pairs_corr,
         filename = paste0(path_save, "/posterior-IMIS-correlation.png"),
         width = 12, 
         height = 12)
  
  ggsave(plot = gg_post_imis,
         filename = paste0(path_save, "/posterior_vs_prior-IMIS.png"),
         width = 10, 
         height = 6)
}

## 05.02 Save data ---------------------------------------------------------

df_calib_post <- m_calib_post %>% 
  as.data.frame(row.names = 1:nrow(.)) %>% 
  mutate(likelihood = v_calib_post)

# Obtain sample for prior distribution
set.seed(seed)
m_prior_samp <- sample.prior(n_samp = 1000)
set.seed(NULL)

df_prior_samp <- m_prior_samp %>% 
  as.data.frame()


# Store the calibration outputs in a list
l_outputs_calib <- list(df_prior        = df_prior_samp,
                        df_calib_post   = df_calib_post,
                        l_output_IMIS   = l_fit_imis,
                        marg_likelihood = n_marg_lik)

if (save_out == TRUE) {
  # Save calibration inputs and outputs
  saveRDS(object = l_params_all,    file = paste0(path_save, "/l_params_all.rds"))
  saveRDS(object = l_outputs_calib, file = paste0(path_save, "/l_outputs_calib.rds"))
}




# 06 Validation -----------------------------------------------------------

# # Define the path to read previous calibration results (all quarterly)
# path_read <- paste0("Section_2_TMB_demo/output/TMB_less/calib_2026_06_18_15h48m")
# 
# # Read previous calibration inputs and outputs
# l_params_all     <- readRDS(file = paste0(path_read, "/l_params_all.rds"))
# l_outputs_calib  <- readRDS(file = paste0(path_read, "/l_outputs_calib.rds"))


## 06.01 Define global variables ----------------------------------------------

n_time       <- length(l_params_all$v_time)
v_names_time <- as.character(l_params_all$v_time)

## 06.02 Load calibration outputs ------------------------------

# Get the prior distribution values
df_prior_samp <- l_outputs_calib$df_prior

# Get the calibrated posterior values
df_calib_post <- l_outputs_calib$df_calib_post


## 06.03 Compute outputs from calibrated parameters ---------------------------

# Number of posterior samples
n_samp <- nrow(df_calib_post)

### Define matrices to store model outputs
m_OS  <- matrix(NA, nrow = n_samp, ncol = n_time)
m_PFS <- matrix(NA, nrow = n_samp, ncol = n_time) 

colnames(m_OS) <- colnames(m_PFS) <- v_names_time

### Create data frames with model predicted outputs
df_PFS <- data.frame(Outcome = "PFS", m_PFS, check.names = F)
df_OS  <- data.frame(Outcome = "OS",  m_OS,  check.names = F)

# Evaluate model at each posterior sample and store results
for(i in 1:n_samp){
  
  l_out_post <- calibration_out(m_params_calib = df_calib_post[i, ],
                                l_params_all   = l_params_all)
  
  df_PFS[i,-1] <- l_out_post$v_PFS
  df_OS[i,-1]  <- l_out_post$v_OS
  
  # display progress
  cat('\r', paste(round(i/n_samp * 100), "% done", sep = " ")) 
}


### Combine all outputs
df_out_valid <- rbind(df_PFS, df_OS)

### Transform data.frame to long format
df_out_valid_long <- reshape2::melt(data = df_out_valid,
                                    id.vars = "Outcome",
                                    variable.name = "Time")

### Compute posterior-predicted 95% CI
df_out_valid_sum <- data_summary(df_out_valid_long, 
                                 varname = "value",
                                 groupnames = c("Outcome", "Time"))

df_out_valid_sum$Time <- as.numeric(as.character(df_out_valid_sum$Time))

df_out_valid_sum %>% 
  group_by(Outcome) %>% 
  summarise(le = sum(value))


df_out_valid_sum <- df_out_valid_sum %>% 
  dplyr::mutate(Source = "Model") %>%
  dplyr::select(Source, Outcome, Time, S = value, se = sd, lb, ub)


df_targets_plt <- l_params_all$dt_base %>% 
  mutate(Source = "Calibration target",
         target = type) %>% 
  select(Source, 
         Outcome = target,
         Time = time, 
         S = survival, 
         se,
         lb = lower_95_CI,
         ub = upper_95_CI)


### Combine model-predicted outputs with targets
df_model_n_targets <- dplyr::bind_rows(df_out_valid_sum, 
                                       df_targets_plt)

df_model_n_targets <- df_model_n_targets %>% 
  mutate(Outcome = if_else(condition = Outcome == "OS", 
                           true  = "Overall survival", 
                           false = "Progression-free survival")) %>% 
  filter(Time %in% unique(df_out_valid_sum$Time))

## 06.04 Plotting -----------------------------------------------------------

gg_valid <- ggplot(mapping = aes(x     = Time, 
                                 y     = S,
                                 ymin  = lb, 
                                 ymax  = ub,
                                 fill  = Source, 
                                 color = Source,
                                 shape = Source)) +
  geom_line(data = filter(df_model_n_targets, Source == "Model"),
            linewidth = 0.85) +
  geom_point(data = filter(df_model_n_targets, Source != "Model"), 
             size = 3) +
  geom_errorbar(data = filter(df_model_n_targets, Source != "Model")) +
  geom_ribbon(data   = filter(df_model_n_targets, Source == "Model"),
              alpha = 0.3,
              colour = NA) +
  facet_wrap(~Outcome) +
  # scale_x_continuous(breaks = unique(df_model_n_targets$Time)) +
  scale_x_continuous(breaks = scales::pretty_breaks(n = 5)) +
  scale_y_continuous(n.breaks = 8, limits = c(0, 1)) +
  scale_color_manual(values = c("Calibration target" = "gray25", "Model" = "red")) +
  scale_fill_manual(values  = c("Calibration target" = "gray25", "Model" = "red")) +
  scale_shape_manual(values = c("Calibration target" = 1, "Model" = NA)) +
  xlab("Cycles") +
  ylab("Probability of survival") +
  theme_bw(base_size = 28) +
  theme(legend.position = "bottom",
        legend.title = element_blank(),
        strip.background = element_rect(fill = "white",
                                        color = "white"),
        # strip.text = element_text(size = 14, face = "bold"),
        # strip.text = element_text(face = "bold"),
        legend.box.margin = margin(t = -20, b = -10))

# gg_valid

## 06.05 Save plots ---------------------------------------------------------

if (save_out == TRUE) {
  
  ggsave(plot = gg_valid,
         filename = paste0(path_save, "/plt_validation.png"),
         height = 6, 
         width = 10)
  
}
