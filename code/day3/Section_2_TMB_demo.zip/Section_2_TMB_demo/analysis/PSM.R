#* Title: PSM
#* 
#* Code function: 
#*    This script implements and saves the outputs of a Partitioned Survival 
#*    Model (PSM) using the reconstructed Individual Patient Data (IPD) 
#*    generated in `data-raw/digitize_reconstruct_IPD.R`
#* 
#* Authors: David U. Garibay-Treviño and Alexandra Moskalewicz on behalf of the DARTH work group


# 01 Initial Setup --------------------------------------------------------

## 01.01 Clean environment ------------------------------------------------

rm(list = ls())
gc()

## 01.02 Load libraries ----------------------------------------------------

# Install packages from CRAN (if required) and load packages
if (!require('pacman')) install.packages('pacman'); library(pacman)
p_load("tidyverse", "survival", "survHE")

#install_github("DARTH-git/darthtools", force = TRUE) ## load (install if required) packages from GitHub. Click "Enter" when they ask about what  to update
p_load("DARTH-git/darthtools")

## 01.03 Load functions ----------------------------------------------------

#No functions are required in this file

## 01.04 Specifications ----------------------------------------------------

cycle_length    <- 1  # cycle length (a month). [Use 1 for annual, 0.5 for biannual]

times <- seq(from = 0, 
             to   = 30, #specify the end of the desired extrapolation period
             by   = cycle_length) 
#Using these parameters, the PSM will run from 0-18 months, in monthly intervals

# Define the state space of the 3-state model
v_names_states  <- c("Progressionfree", "Progressed","Death")  # state names

# 02 Construct PSM --------------------------------------------------------

# #*Load IPD that was reconstructed from the digitized curves
IPD_reconstructed <- read.csv(file = "Section_2_TMB_demo/data-raw/TMB_less/IPD_reconstructed.csv")

df_recon_IPD_OS <- IPD_reconstructed %>% filter(type == "OS")

df_recon_IPD_PFS <- IPD_reconstructed %>% filter(type == "PFS")


# Fit parametric survival models
fit_PFS <- fit.models(Surv(time,status)~1,
                      data = df_recon_IPD_PFS,
                      distr =   c("exp", "weibull", "gamma", "lnorm", "llogis", "gompertz"))

fit_OS  <- fit.models(Surv(time,status)~1,
                      data = df_recon_IPD_OS,
                      distr =   c("exp", "weibull", "gamma", "lnorm", "llogis", "gompertz"))

# Check AIC of each model to assess goodness-of-fit
GoF_PFS <- data.frame(AIC = fit_PFS$model.fitting$aic,
                      BIC = fit_PFS$model.fitting$bic)

GoF_OS  <- data.frame(AIC = fit_OS$model.fitting$aic,
                      BIC = fit_OS$model.fitting$bic)

rownames(GoF_PFS) <- 
  rownames(GoF_OS) <- names(fit_OS$models)

# Select best-fitting models
choose_PFS <- rownames(GoF_PFS)[which.min(GoF_PFS$AIC)]
choose_OS  <- rownames(GoF_OS)[which.min(GoF_OS$AIC)]

#* construct a partitioned survival model (PSM) out of the chosen models

#Deterministic
m_M_PSM <- darthtools::partsurv(pfs_survHE = fit_PFS,
                                os_survHE  = fit_OS,
                                choose_PFS = choose_PFS, 
                                choose_OS  = choose_OS,
                                time       = times,
                                v_names_states = v_names_states)

darthtools::plot_trace_PSM(time = times, 
                           partsurv.model = m_M_PSM, 
                           PA = F, 
                           v_names_states = v_names_states)

#Probabilistic
#* using size of `n_sim`
m_M_PSM_PSA <- darthtools::partsurv(pfs_survHE = fit_PFS,
                                    os_survHE  = fit_OS,
                                    choose_PFS = choose_PFS,
                                    choose_OS  = choose_OS,
                                    time = times,
                                    v_names_states = v_names_states,
                                    PA = T, 
                                    n_sim = 1000)

darthtools::plot_trace_PSM(time           = times, 
                           partsurv.model = m_M_PSM_PSA, 
                           PA             = T, 
                           v_names_states = v_names_states)

# Compute 95% Interquantile ranges (IQR) among different model realizations
m_PSM_OS_95_IQR <- matrixStats::rowQuantiles(x = m_M_PSM_PSA$os.surv, probs = c(0.025, 0.5, 0.975))
m_PSM_PFS_95_IQR <- matrixStats::rowQuantiles(x = m_M_PSM_PSA$pfs.surv, probs = c(0.025, 0.5, 0.975))

# Convert to data frame, add time column, and rename IQR columns
## OS
OS_PSM <- m_PSM_OS_95_IQR %>% 
  as_tibble() %>% 
  mutate(time = times, .before = 1) %>% 
  rename(lb     = `2.5%`,
         median = `50%`,
         ub     = `97.5%`)

## PFS
PFS_PSM <- m_PSM_PFS_95_IQR %>%  
  as_tibble() %>% 
  mutate(time = times, .before = 1) %>% 
  rename(lb     = `2.5%`,
         median = `50%`,
         ub     = `97.5%`)

# Save for use in "compare_PSM_STM.R" file
write.csv(x = OS_PSM,  file = "Section_2_TMB_demo/data-raw/TMB_less/OS_PSM.csv",  row.names = FALSE)
write.csv(x = PFS_PSM, file = "Section_2_TMB_demo/data-raw/TMB_less/PFS_PSM.csv", row.names = FALSE)


