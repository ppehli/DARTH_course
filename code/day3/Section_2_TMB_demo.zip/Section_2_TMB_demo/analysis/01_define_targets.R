#* Title: 01_define_targets
#* 
#* Code function: This code emulates the process of *digitizing published*
#*                *Kaplan-Meier (KM) curves* for overall survival (OS) and progression-free survival (PFS)
#*                to then *reconstruct their respective Individual Patient Data (IPD) data sets*. 
#*                
#*                Next, we use the reconstructed IPD to capture uncertainty around the fit KM curves that will
#*                serve as *calibration targets* in the following scripts
#*                contained in the  `analysis` folder
#*                
#*                Manual specifications based on the trial data you'd like to calibrate are required in:
#*                *section 02.01 * - specify image paths for published OS/PFS curves, specify information on the curves for digitizing
#*                *section 02.01 * - specify the intervention (trial arm)
#*                *section 03    * - define targets
#*                *section 04.01 * - specify information from the trial's at-risk tables prior to reconstructing IPD
#*                *section 05    * - specify model specifications that will be carried forward to the subsequent file
#*                
#*  Note [June 18, 2026]:
#*  - The functions inside R/multistate_calibration_functions.R correspond
#*    to their current version in the *dev* branch of the 
#*    *multi-state-calibration* repository
#*  
#* 
#* Authors: 
#* - David U. Garibay-Treviño and Alexandra Moskalewicz on behalf of the DARTH work group


# 01 Initial Setup --------------------------------------------------------

## 01.01 Clean environment ------------------------------------------------

rm(list = ls())
gc()

## 01.02 Load libraries ----------------------------------------------------

# Install packages from CRAN (if required) and load packages
if (!require('pacman')) install.packages('pacman'); library(pacman)
p_load("tidyverse", "survival")

## 01.03 Load functions ----------------------------------------------------

#No functions are required in this file

## 01.04 Define global variables -------------------------------------------

# No Global variables to define in this file

# 03 Define targets -----------------------------------------

#This dataset contains 18 months of data. We would like to have 1 target per month.
v_target_times <- seq(from = 0,  #first target
                      to   = 18, #last target
                      by   = 1)  #target length 


# Load reconstructed IPD
df_IPD_all <- read.csv(file = "Section_2_TMB_demo/data-raw/TMB_less/IPD_reconstructed.csv")


## 04.03 Fit survival model -----------------------------------

#* Fit a KM model using the reconstructed IPD from the digitized data

sfit_reconstructed_KM <- survival::survfit(formula = Surv(time, status) ~ type, 
                                           data    = df_IPD_all)


#* Forecast the fitted model using the vector of target times
#* Obtain survival estimates 
rec_KM_surv_curves <- summary(
  object = sfit_reconstructed_KM,
  times  = v_target_times,
  extend = TRUE)


# Construct target dataset with reconstructed KM
df_rec_KM_surv_curves <- tibble(
  target      = "Survival",
  type        = stringr::str_sub(rec_KM_surv_curves$strata, 6, -1),
  time        = rec_KM_surv_curves$time,
  n.risk      = rec_KM_surv_curves$n.risk,
  n.event     = rec_KM_surv_curves$n.event,
  survival    = rec_KM_surv_curves$surv,
  se          = rec_KM_surv_curves$std.err,
  lower_95_CI = rec_KM_surv_curves$lower,
  upper_95_CI = rec_KM_surv_curves$upper)

# Compute the variance from the survival estimates
df_rec_KM_surv_curves <- df_rec_KM_surv_curves %>% 
  mutate(var = se^2, .after = "se")

#Visualize the calibration targets
plot_calib_targets <- ggplot(data = df_rec_KM_surv_curves,
                             mapping = aes(x = time,
                                           y = survival,
                                           color = type,
                                           fill = type,
                                           ymin = lower_95_CI,
                                           ymax = upper_95_CI)) +
  theme_bw(base_size = 18) +
  geom_point(size = 1) +
  geom_errorbar() +
  scale_x_continuous(breaks = seq(0, 18, 3)) +
  scale_y_continuous(breaks = seq(0, 1, 0.2)) +
  theme(legend.position = "none") +
  coord_cartesian(ylim = c(0, 1)) +
  labs(color = "Type: ",
       fill = "Type: ",
       y = "Survival",
       x = "Time") +
  facet_wrap(~type)

plot_calib_targets

## 04.04 Save calibration targets ------------------------------------------

##Save data set to be used as calibration targets in subsequent files
write.csv(x = df_rec_KM_surv_curves,
          file = "Section_2_TMB_demo/data-raw/TMB_less/KM_targets.csv",
          row.names = FALSE)

##Save visualization of calibration targets
ggsave(plot = plot_calib_targets,
       filename = "Section_2_TMB_demo/figs/TMB_less/KM_targets_plot.png",
       height = 6,
       width = 10)


