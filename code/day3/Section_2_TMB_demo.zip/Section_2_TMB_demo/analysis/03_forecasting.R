#* Title: 03_forecasting
#* 
#* Code function: 
#*    This code uses the parameter set obtained in the 
#*    `02_calibration.R` script. 
#*    
#*    To do that, the `l_outputs_calib.rds` data set is imported, then
#*    the parameter set is extracted. 
#*    
#*    As well, we update the values of `l_params_all()` to extend the times 
#*    in the analysis.
#*    
#*    
#*    This script generates the following outputs:
#*    - OS and PFS values for the extended periods of time
#*    - The cohort trace
#*    
#*    #*Manual specifications based on the trial data you'd like to calibrate are required in:
#*                *section 01.04 * - specify path_read so that appropriate results can be referenced
#*                *section 02    * - specify the forecasting time period
#* 
#* 
#* Authors: 
#* - David U. Garibay-Treviño and Alexandra Moskalewicz on behalf of the DARTH work group

# 01 Initial Setup --------------------------------------------------------

## 01.01 Clean environment ------------------------------------------------

remove(list = ls())
gc()

## 01.02 Load libraries ----------------------------------------------------

# Install packages from CRAN (if required) and load packages
if (!require('pacman')) install.packages('pacman'); library(pacman)
p_load("tidyverse", "scales", "matrixStats")


## 01.03 Load functions ----------------------------------------------------

source("Section_2_TMB_demo/R/multi-state-calibration-functions.R")


# 01.04 Specifications ----------------------------------------------------

# Save output?
save_out <- TRUE

#* Define the path to read previous calibration results. Read in results from 
#* previous calibration
#* - *Note:* If save_out == TRUE, the forecasted results will be saved in a folder in this same path

path_read <- "Section_2_TMB_demo/output/TMB_less/calib_2026_06_18_15h48m"


#* Read previous calibration inputs and outputs
l_params_all <- readRDS(file = paste0(path_read, "/l_params_all.rds"))
dist_PF_P          <- as.character(l_params_all[["dist_PF_P"]])
dist_PF_D          <- as.character(l_params_all[["dist_PF_D"]])
dist_P_D           <- as.character(l_params_all[["dist_P_D"]])

# # 02 Define global variables --------------------------------------------

#*Specify the *extended time horizon* to forecast the model results
v_new_time <- seq(from = 0, to = 30, by = 1)

l_params_updated <- list(v_time   = v_new_time,
                         n_cycles = length(v_new_time))

#* Update model parameters used in calibration
#* `update_param_list()` is defined in "R/01_model_input_functions.R"
l_params_new <- update_param_list(l_params_all   = l_params_all,
                                  params_updated = l_params_updated)


# 03 Load data ----------------------------------------------------------


## 03.01 Load target data ------------------------------------------------

## data from reconstructed KM curves.
df_targets <- as.data.frame(l_params_new$dt_base)


## 03.02 Load calibration output data ------------------------------------

# Load posterior distribution from calibration using IMIS
l_calib_out  <- readRDS(file = paste0(path_read, "/l_outputs_calib.rds"))

# Get the calibrated posterior values
df_calib_post <- l_calib_out$df_calib_post

# 04 Run model ----------------------------------------------------------

## 04.01 Using posterior distribution --------------------------------------

# Generate matrix to contain output from calibrated parameter sets
m_OS_calib <- m_PFS_calib <- matrix(data = 0,
                                    nrow = nrow(df_calib_post),
                                    ncol = length(l_params_new$v_time))

colnames(m_OS_calib) <- colnames(m_PFS_calib) <- l_params_new$v_time 


# Run model using all the calibrated posterior distribution.
for (i in 1:nrow(df_calib_post)) {
  
  # Run model for parameter set
  l_model_res <- calibration_out(m_params_calib = df_calib_post[i, ], 
                                 l_params_all   = l_params_new)
  
  # Store model results
  m_OS_calib[i, ]  <- l_model_res$v_OS
  m_PFS_calib[i, ] <- l_model_res$v_PFS
  
  # display progress
  cat('\r', paste(round(i/nrow(df_calib_post) * 100), "% done", sep = " ")) 
}


# 05 Plotting -----------------------------------------------------------


# 05.01 Extended OS and PFS -----------------------------------------------


df_95_IQR <- get_calib_95_IQR(m_OS_calib = m_OS_calib,
                              m_PFS_calib = m_PFS_calib)

plt_calib_outputs_95_IQR <- plot_forecasting(df_95_IQR  = df_95_IQR,
                                             df_targets = df_targets)


plt_calib_outputs_95_IQR


## 05.02 Cohort trace ------------------------------------------------------

plt_M_forecast_calib <- plot_cohort_trace(l_model_output = l_model_res)

plt_M_forecast_calib


# 07 Save outputs -------------------------------------------------------

if (save_out == TRUE) {
  
  # Define path to save forecasted results
  path_save <- paste0(path_read, "/forecasted_results")
  
  # Create folder to save forecasted results
  dir.create(path = path_save)
  
  # Forecasted results
  saveRDS(object = l_model_res, file = paste0(path_save, "/l_forecast_results.rds"))
  
  # 95% Interquantile range of forecasted OS and PFS
  saveRDS(object = df_95_IQR, file = paste0(path_save, "/df_forecast_surv_95_IQR.rds"))
  
  # Save plots
  
  ## 95% IQR of forecasted survival curves
  ggsave(plot = plt_calib_outputs_95_IQR,
         filename = paste0(path_save, "/plt_forecast_surv_95_IQR.png"),
         width = 10,
         height = 6)
  
  ## Forecasted cohort trace using MAP parameter set
  ggsave(plot = plt_M_forecast_calib,
         filename = paste0(path_save, "/plt_MAP_forecast_M.png"),
         width = 10,
         height = 6)
  
}
