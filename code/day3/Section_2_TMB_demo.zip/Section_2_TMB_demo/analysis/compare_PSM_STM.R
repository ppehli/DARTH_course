#* Title: compare_PSM_STM
#* 
#* Code function:
#*    This script compares the results of a Partitioned Survival Model (PSM) 
#*    against the outputs of the State-transition model (STM)
#*    defined, calibrated, and forecasted in files `01_define_targets.R`, 
#*    `02_calibration.R`, and `03_forecasting.R`, respectively.
#* 
#* Authors: David U. Garibay-Treviño and Alexandra Moskalewicz on behalf of the DARTH work group

# 01 Initial Setup --------------------------------------------------------

## 01.01 Clean environment ------------------------------------------------
remove(list = ls())

#* Refresh environment memory
gc()

# disable scientific notation
options(scipen=999) 

## 01.02 Load libraries ----------------------------------------------------

if (!require('pacman')) install.packages('pacman'); library(pacman)
# load (install if required) packages from CRAN
p_load("tidyverse", "devtools", "flexsurv", "survHE", "msm", "igraph", "mstate", "reshape2", 
       "matrixStats", "knitr", "diagram", "abind", "data.table", "scales", "patchwork")

# load (install if required) packages from GitHub
#install_github("DARTH-git/darthtools", force = TRUE) #Uncomment if there is a newer version
p_load_gh("DARTH-git/darthtools")

## 01.03 Load functions ----------------------------------------------------

#No functions are required in this file

## 01.04 Define global variables -------------------------------------------

# Path to retrieve previous calibrated STM results
path_read <- "Section_2_TMB_demo/output/TMB_less/calib_2026_06_18_15h48m"

# Get list of parameters used while calibrating the STM
l_params_all <- readRDS(file = paste0(path_read, "/l_params_all.rds"))
v_target_time <- l_params_all$v_target_time

# 02 Load results from PSM and calibrated STM --------------------------------------------------------

## 02.0 Calibrated STM ----------------------------------------------------

# Read forecasted results
df_forecast_surv_95_IQR <-  readRDS(paste0(path_read, "/forecasted_results/df_forecast_surv_95_IQR.rds"))

df_forecast_surv_95_IQR <- df_forecast_surv_95_IQR %>% 
  dplyr::rename(lb = lb_95, ub = ub_95) %>% 
  mutate(model = "cSTM")

# Keep only OS information
OS_c  <- df_forecast_surv_95_IQR %>% 
  filter(type == "OS") %>% 
  dplyr::select(!type)

# Keep only PFS information
PFS_c <- df_forecast_surv_95_IQR %>% 
  filter(type == "PFS") %>% 
  dplyr::select(!type)

## 02.1 PSM ----------------------------------------------------

# Read PSM results
OS_PSM  <- read.csv(file = "Section_2_TMB_demo/data-raw/TMB_less/OS_PSM.csv")
PFS_PSM <- read.csv(file = "Section_2_TMB_demo/data-raw/TMB_less/PFS_PSM.csv")

## Add columns defining the model type
OS_PSM$model  <- "PSM"
PFS_PSM$model <- "PSM"

## 02.2 Digitized curves ----------------------------------------------------

# Read data from digitized OS and PFS curves 
OS_digitized  <- read.csv(file = "Section_2_TMB_demo/data-raw/TMB_less/OS_digitized.csv")
PFS_digitized <- read.csv(file = "Section_2_TMB_demo/data-raw/TMB_less/PFS_digitized.csv")

# Add and rename columns 
OS_digitized <- OS_digitized %>% 
  rename(median = St) %>% 
  mutate(model = "Digitized")

PFS_digitized <- PFS_digitized %>% 
  rename(median = St) %>% 
  mutate(model = "Digitized")


## 02.3 Calibration targets ----------------------------------------------------

# Get targets used to calibrate STM
dt_targets <- l_params_all$dt_base

## 03 Plot and Compare Model Types ----------------------------------------------------

df_models_OS <- bind_rows(OS_c, 
                          OS_PSM, 
                          OS_digitized)

### add uncertainty bounds for both models

#Plot OS comparison
plot_OS_comparison <- ggplot(mapping = aes(x = time)) +  
  theme_bw(base_size = 18) +
  geom_line(data = OS_PSM, 
            mapping = aes(y     = median, 
                          color = "PSM"),
            linewidth = 1.4) +
  geom_line(data = OS_c,
            mapping = aes(y     = median, 
                          color = "Calibrated STM"),
            linewidth = 1.4) + 
  geom_line(data = OS_digitized,
            mapping = aes(y     = median,
                          color = "Digitized"),
            linewidth = 1.4) +
  geom_ribbon(data = OS_c, 
              mapping = aes(x    = time, 
                            ymin = lb, 
                            ymax = ub, 
                            fill = "Calibrated STM"),
              alpha = 0.3) +
  theme(legend.position = "bottom") + 
  scale_colour_manual(values = c("Calibrated STM" = "red",
                                 "PSM" = "#00BA38",
                                 "Digitized" = "black"),
                      breaks = c("Calibrated STM",
                                 "PSM",
                                 "Digitized")) +
  guides(colour = guide_legend(nrow = 1),
         fill   = "none") +
  labs(x = "Months from diagnosis", 
       y = "Probability of survival", 
       title = "Overall survival",
       color = "Source: ") + 
  ylim(0, 1) +
  scale_x_continuous(breaks       = seq(0, 30, by = 3), 
                     minor_breaks = seq(0, 30, by = 1)) +
  geom_vline(xintercept = 18, linetype = "longdash", linewidth = 1.4)

print(plot_OS_comparison)

##Add error bars from calibration targets
plot_OS_comparison_targets <- plot_OS_comparison + 
  geom_errorbar(data = filter(.data = dt_targets, type == "OS"), 
                mapping = aes(x    = time, 
                              y    = survival, 
                              ymin = lower_95_CI, 
                              ymax = upper_95_CI), 
                width = 0.2, 
                color = "red")

print(plot_OS_comparison_targets)

#Plot PFS comparison
plot_PFS_comparison <- ggplot(mapping = aes(x = time)) +  
  theme_bw(base_size = 18) +
  geom_line(data = PFS_PSM, 
            mapping = aes(y     = median, 
                          color = "PSM"),
            linewidth = 1.4) +
  geom_line(data = PFS_c,
            mapping = aes(y     = median, 
                          color = "Calibrated STM"),
            linewidth = 1.4) + 
  geom_line(data = PFS_digitized,
            mapping = aes(y     = median,
                          color = "Digitized"),
            linewidth = 1.4) +
  geom_ribbon(data = PFS_c, 
              mapping = aes(x    = time, 
                            ymin = lb, 
                            ymax = ub, 
                            fill = "Calibrated STM"),
              alpha = 0.3) +
  theme(legend.position = "bottom") + 
  scale_colour_manual(values = c("Calibrated STM" = "red",
                                 "PSM" = "#00BA38",
                                 "Digitized" = "black"),
                      breaks = c("Calibrated STM",
                                 "PSM",
                                 "Digitized"
                      )) +
  guides(colour = guide_legend(nrow = 1),
         fill   = "none") +
  labs(x = "Months from diagnosis", 
       y = "Probability of survival", 
       title = "Progression-free survival",
       color = "Source: ") + 
  ylim(0, 1) +
  scale_x_continuous(breaks       = seq(0, 30, by = 3), 
                     minor_breaks = seq(0, 30, by = 1)) +
  geom_vline(xintercept = 18, linetype = "longdash", linewidth = 1.4)

print(plot_PFS_comparison)

##Add error bars from calibration targets
plot_PFS_comparison_targets <- plot_PFS_comparison +
  geom_errorbar(data = filter(.data = dt_targets, type == "PFS"),
                mapping = aes(ymin = lower_95_CI, 
                              ymax = upper_95_CI), 
                width = 0.2, 
                color = "red")

print(plot_PFS_comparison_targets)

